CODEDOJO DAILY - STATIC EDITION (HTML + CSS + JavaScript only, no server)

HOW TO RUN
1. Extract the ZIP and open the codedojo-daily folder.
2. Open index.html in Chrome/Edge/Firefox. (Best: VS Code + Live Server, because secure
   password hashing uses the browser's Web Crypto, which needs https, localhost or file://.)
3. Sign up with a username and a password, then log in. Demo users (Asha, Ravi...) are
   leaderboard-only and cannot log in.
4. Automated tests: open tests/tests.html - it should show "10 of 10 tests passed".

FILES
index.html      page shell + Content-Security-Policy
style.css       styling (unchanged look)
js/problems.js  34 challenges (17 executed JavaScript, 17 rule-checked) with tags + 5 tests each
js/storage.js   saved data, seed data, escape + safe lookup helpers
js/scoring.js   points, streaks, unlocking, daily problem, team leaderboard (pure functions)
js/auth.js      sign up / log in, salted PBKDF2 password hashes, lockout, session expiry
js/runner.js    Web Worker sandbox for JavaScript, comment-safe rule checks for Python/HTML/CSS
js/views.js     HTML for each screen
js/app.js       routing, button actions, events
tests/          automated tests

SECURITY FEATURES
- Passwords are never stored: random 16-byte salt + PBKDF2-SHA256 (150,000 rounds).
- Password rules: 8-64 characters, at least one letter and one number, not equal to username.
- 5 wrong passwords lock the account for 60 seconds; same error for unknown users.
- Session in sessionStorage, signed out after 30 minutes idle, and on Log out / closing the tab.
- All user text is HTML-escaped; names are checked with hasOwnProperty (no "constructor" tricks).
- Content-Security-Policy: only own scripts, no inline scripts, no outside script sources.
- Learner code runs in a Worker with a 2.5 s limit; fetch/XHR/WebSocket are removed.
- Preview iframe is fully sandboxed; code is limited to 20,000 characters.

HONEST LIMITATIONS (say these in your viva)
- It is a static site, so data lives in this browser's localStorage. Another device sees different data.
- Client-side login protects passwords and blocks casual access, but anyone with DevTools can edit
  their own browser's saved data. A real server (Node/Express + database) is the production answer.
- Python / HTML / CSS tasks are checked by rules, not executed.
