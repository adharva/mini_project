/* server.js - starts the app. Environment: PORT (3000), DB_FILE (data/codedojo.db), TZ_OFFSET_MINUTES (330 = India), SECURE_COOKIES=1 behind https. */
'use strict';
const path = require('node:path');
const fs = require('node:fs');
const { createApp } = require('./app');

const dataDir = path.join(__dirname, '..', 'data');
fs.mkdirSync(dataDir, { recursive: true });
const { server } = createApp({
  dbFile: process.env.DB_FILE || path.join(dataDir, 'codedojo.db'),
  demo: process.env.DEMO !== '0',
  publicDir: path.join(__dirname, '..', '..', 'frontend'),
  secureCookies: process.env.SECURE_COOKIES === '1',
  tzMinutes: Number(process.env.TZ_OFFSET_MINUTES ?? 330)
});
const port = Number(process.env.PORT) || 3000;
server.listen(port, '127.0.0.1', () => console.log(`CodeDojo Daily running at http://localhost:${port}`));
