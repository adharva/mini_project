/* db.js - SQLite schema, seed data and a transaction helper (built-in node:sqlite, no install needed). */
'use strict';
const { DatabaseSync } = require('node:sqlite');
const path = require('node:path');
const { dateString } = require('./scoring');
const PROBLEMS = require('../data/problems.json');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS teams (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE COLLATE NOCASE, avatar INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE COLLATE NOCASE, password_hash TEXT,
  failed_logins INTEGER NOT NULL DEFAULT 0, locked_until INTEGER NOT NULL DEFAULT 0,
  team_id INTEGER REFERENCES teams(id) ON DELETE SET NULL, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS problems (
  id INTEGER PRIMARY KEY, title TEXT NOT NULL, difficulty TEXT NOT NULL CHECK (difficulty IN ('Easy','Medium','Hard')),
  tag TEXT NOT NULL, kind TEXT NOT NULL, fn TEXT, params TEXT, description TEXT NOT NULL, starter TEXT,
  tests TEXT NOT NULL, checks TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS attempts (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, problem_id INTEGER NOT NULL REFERENCES problems(id),
  started_at INTEGER NOT NULL, PRIMARY KEY (user_id, problem_id));
CREATE TABLE IF NOT EXISTS submissions (
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  problem_id INTEGER NOT NULL REFERENCES problems(id), verdict TEXT NOT NULL, passed INTEGER NOT NULL, total INTEGER NOT NULL,
  code TEXT NOT NULL, similar_to INTEGER, similarity REAL, created_at INTEGER NOT NULL);
-- The primary key means a user can be rewarded for a problem only once (no duplicate-submission scoring).
CREATE TABLE IF NOT EXISTS solves (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, problem_id INTEGER NOT NULL REFERENCES problems(id),
  seconds INTEGER NOT NULL, points INTEGER NOT NULL, solved_date TEXT NOT NULL, PRIMARY KEY (user_id, problem_id));
CREATE INDEX IF NOT EXISTS idx_sub_problem ON submissions(problem_id, verdict);
CREATE INDEX IF NOT EXISTS idx_users_team ON users(team_id);`;

function seedProblems(db) {
  if (db.prepare('SELECT COUNT(*) AS n FROM problems').get().n > 0) return;
  const insert = db.prepare('INSERT INTO problems VALUES (?,?,?,?,?,?,?,?,?,?,?)');
  PROBLEMS.forEach(p => insert.run(p.id, p.title, p.difficulty, p.tag, p.kind, p.fn, p.params, p.description,
    p.starter, JSON.stringify(p.tests), JSON.stringify(p.checks)));
}

// Demo squads so the leaderboard is not empty. Demo users have no password, so nobody can log in as them.
function seedDemo(db, tzMinutes) {
  if (db.prepare('SELECT COUNT(*) AS n FROM users').get().n > 0) return;
  const now = Date.now(), day = n => dateString(n, new Date(), tzMinutes);
  const demo = {
    'Binary Beasts': { Asha: { 1: [240, 0], 2: [400, 1], 3: [500, 2], 7: [1300, 3] }, Ravi: { 1: [600, 0], 5: [300, 1] }, Meena: { 4: [700, 1] } },
    'Code Owls': { Kiran: { 1: [200, 0], 2: [260, 1], 4: [900, 2], 8: [1000, 3] }, Zoya: { 2: [700, 1] }, Dev: { 3: [800, 2] } },
    'Pixel Pandas': { Neha: { 1: [500, 0], 3: [300, 1] }, Omar: { 2: [600, 1] }, Tara: { 4: [1000, 3] } }
  };
  const { solveScore } = require('./scoring');
  Object.entries(demo).forEach(([team, members], teamIndex) => {
    const teamId = db.prepare('INSERT INTO teams (name, avatar, created_at) VALUES (?,?,?)').run(team, teamIndex, now).lastInsertRowid;
    Object.entries(members).forEach(([name, solved]) => {
      const userId = db.prepare('INSERT INTO users (name, team_id, created_at) VALUES (?,?,?)').run(name, teamId, now).lastInsertRowid;
      Object.entries(solved).forEach(([problemId, [seconds, daysAgo]]) => {
        const problem = db.prepare('SELECT difficulty FROM problems WHERE id = ?').get(+problemId);
        db.prepare('INSERT INTO solves VALUES (?,?,?,?,?)').run(userId, +problemId, seconds, solveScore(problem.difficulty, seconds), day(daysAgo));
      });
    });
  });
}

function openDb({ file = ':memory:', demo = false, tzMinutes = 330 } = {}) {
  const db = new DatabaseSync(file);
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec(SCHEMA);
  seedProblems(db);
  if (demo) seedDemo(db, tzMinutes);
  return db;
}

// Run several statements all-or-nothing, e.g. "check the squad has space, then join it".
function transaction(db, work) {
  db.exec('BEGIN IMMEDIATE');
  try { const result = work(); db.exec('COMMIT'); return result; }
  catch (error) { db.exec('ROLLBACK'); throw error; }
}

module.exports = { openDb, transaction };
