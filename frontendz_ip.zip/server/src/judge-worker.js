/* judge-worker.js - runs ONE submission in an isolated worker thread (no env vars, memory limited). */
'use strict';
const { parentPort, workerData } = require('node:worker_threads');
const vm = require('node:vm');
const { code, fn, testsJson } = workerData;

// Everything crosses into the sandbox as plain strings, so no host objects leak in (a known vm escape).
const context = vm.createContext(Object.create(null), { codeGeneration: { strings: true, wasm: false } });

// Step 1: install the runner BEFORE learner code. It keeps its own copies of JSON/Reflect,
// so learner code cannot change them to fake a pass.
vm.runInContext(`(() => {
  const stringify = JSON.stringify, parse = JSON.parse, apply = Reflect.apply;
  const run = (name, json) => {
    const target = globalThis[name], tests = parse(json), out = [];
    if (typeof target !== 'function') return stringify({ missing: true });
    for (let i = 0; i < tests.length; i++) {
      try { const value = apply(target, undefined, parse(stringify(tests[i][0])));
            out[i] = { ok: true, value: value === undefined ? 'undefined' : stringify(value) }; }
      catch (error) { out[i] = { ok: false, error: String(error && error.message) }; }
    }
    return stringify({ out });
  };
  Object.defineProperty(globalThis, '__run', { value: run, writable: false, configurable: false });
})()`, context);

try {
  new vm.Script(code).runInContext(context, { timeout: 1000 });           // Step 2: learner code (defines the function)
  const raw = vm.runInContext(`__run(${JSON.stringify(fn)}, ${JSON.stringify(testsJson)})`, context, { timeout: 1500 });
  parentPort.postMessage({ raw });
} catch (error) {
  parentPort.postMessage({ timedOut: /timed out/i.test(String(error.message)), error: String(error.message) });
}
