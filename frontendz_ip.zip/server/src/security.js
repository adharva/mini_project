/* security.js - password hashing, sessions, rate limiting, request checks. */
'use strict';
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const scrypt = promisify(crypto.scrypt);

const SESSION_MINUTES = 30;
const COOKIE_NAME = 'cdd_sid';
const NAME_PATTERN = /^[A-Za-z][A-Za-z0-9 ]{2,19}$/;
const DUMMY_HASH = `scrypt$${'00'.repeat(16)}$${'00'.repeat(64)}`;

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

// Format: scrypt$<salt hex>$<hash hex>. A fresh random salt is used for every password.
async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = await scrypt(password, salt, 64);
  return `scrypt$${salt.toString('hex')}$${hash.toString('hex')}`;
}

async function verifyPassword(password, stored) {
  const [, saltHex, hashHex] = stored.split('$');
  const actual = await scrypt(password, Buffer.from(saltHex, 'hex'), 64);
  const expected = Buffer.from(hashHex, 'hex');
  return expected.length === actual.length && crypto.timingSafeEqual(actual, expected);
}

const validateName = name =>
  typeof name === 'string' && NAME_PATTERN.test(name) ? '' : 'Username must be 3-20 characters (letters, numbers, spaces) and start with a letter.';

function validatePassword(password, name = '') {
  if (typeof password !== 'string' || password.length < 8) return 'Password must be at least 8 characters.';
  if (password.length > 64) return 'Password must be 64 characters or fewer.';
  if (!/[A-Za-z]/.test(password) || !/\d/.test(password)) return 'Password needs at least one letter and one number.';
  if (password.toLowerCase() === String(name).toLowerCase()) return 'Password cannot be the same as your username.';
  return '';
}

// Only the SHA-256 of a session token is stored, so a leaked database cannot be used to log in.
const newToken = () => crypto.randomBytes(32).toString('base64url');
const tokenHash = token => crypto.createHash('sha256').update(token).digest('hex');

function parseCookies(header = '') {
  const cookies = {};
  header.split(';').forEach(part => {
    const i = part.indexOf('=');
    if (i > 0) cookies[part.slice(0, i).trim()] = part.slice(i + 1).trim();
  });
  return cookies;
}

function sessionCookie(token, secure, maxAgeSeconds = SESSION_MINUTES * 60) {
  return `${COOKIE_NAME}=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAgeSeconds}${secure ? '; Secure' : ''}`;
}

// Simple in-memory limiter: at most "max" requests per key in each time window.
function createLimiter() {
  const buckets = new Map();
  return (key, max, windowMs) => {
    const now = Date.now();
    const bucket = buckets.get(key);
    if (!bucket || bucket.reset < now) { buckets.set(key, { count: 1, reset: now + windowMs }); return true; }
    return ++bucket.count <= max;
  };
}

// Blocks cross-site requests: if the browser sends an Origin it must be this same site.
function sameOrigin(req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  try { return new URL(origin).host === req.headers.host; } catch (error) { return false; }
}

const SECURITY_HEADERS = {
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; worker-src blob:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer'
};

module.exports = {
  HttpError, hashPassword, verifyPassword, validateName, validatePassword, DUMMY_HASH,
  newToken, tokenHash, parseCookies, sessionCookie, createLimiter, sameOrigin,
  SECURITY_HEADERS, SESSION_MINUTES, COOKIE_NAME
};
