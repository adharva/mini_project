/* judge.js - the server decides every verdict, so scores cannot be forged from the browser.
 * JavaScript: worker thread + vm sandbox with time and memory limits.
 * Python/HTML/CSS: rule checks on the comment-stripped source.
 * NOTE: for a real production service, run the worker inside a container (Docker/gVisor). */
'use strict';
const { Worker } = require('node:worker_threads');
const path = require('node:path');
const PUBLIC_TESTS = 2, MAX_CODE_LENGTH = 20000, UNORDERED_RESULT_IDS = [1];
const IDENTIFIER = /^[A-Za-z_$][\w$]*$/;

function runWorker(problem, code, tests) {
  return new Promise(resolve => {
    let done = false;
    const worker = new Worker(path.join(__dirname, 'judge-worker.js'), {
      workerData: { code, fn: problem.fn, testsJson: JSON.stringify(tests) },
      env: {}, resourceLimits: { maxOldGenerationSizeMb: 64, maxYoungGenerationSizeMb: 16 }
    });
    const finish = result => { if (!done) { done = true; clearTimeout(timer); worker.terminate(); resolve(result); } };
    const timer = setTimeout(() => finish({ timedOut: true }), 3000);
    worker.on('message', finish);
    worker.on('error', error => finish({ error: String(error.message) }));
  });
}

const normalise = (text, unordered) => {
  if (!unordered) return text;
  try { const v = JSON.parse(text); return Array.isArray(v) ? JSON.stringify([...v].sort((a, b) => a - b)) : text; } catch (e) { return text; }
};

// ---- tiny HTML matcher: tags, [attr], [attr="value"], comma lists and "a b" descendants ----
function parseHtml(html) {
  const nodes = [], stack = [], voids = new Set(['img', 'input', 'br', 'hr', 'meta', 'link']);
  for (const m of html.matchAll(/<(\/?)([a-zA-Z][\w-]*)([^>]*)>/g)) {
    const tag = m[2].toLowerCase();
    if (m[1]) { const i = stack.map(n => n.tag).lastIndexOf(tag); if (i >= 0) stack.length = i; continue; }
    const attrs = {};
    for (const a of m[3].matchAll(/([\w:-]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g)) attrs[a[1].toLowerCase()] = a[2] ?? a[3] ?? a[4] ?? '';
    const node = { tag, attrs, ancestors: [...stack] };
    nodes.push(node);
    if (!voids.has(tag) && !m[3].trim().endsWith('/')) stack.push(node);
  }
  return nodes;
}
function matchesCompound(node, compound) {
  const m = compound.match(/^([a-z0-9]*)((?:\[[^\]]+\])*)$/i);
  if (!m || (m[1] && m[1].toLowerCase() !== node.tag)) return false;
  return [...m[2].matchAll(/\[([\w:-]+)(?:=["']?([^\]"']*)["']?)?\]/g)]
    .every(a => Object.prototype.hasOwnProperty.call(node.attrs, a[1].toLowerCase()) && (a[2] === undefined || node.attrs[a[1].toLowerCase()] === a[2]));
}
function countMatches(nodes, selector) {
  return nodes.filter(node => selector.split(',').some(alt => {
    const parts = alt.trim().split(/\s+/);
    if (!matchesCompound(node, parts.pop())) return false;
    let position = node.ancestors.length;
    for (let i = parts.length - 1; i >= 0; i--) {
      do { position--; } while (position >= 0 && !matchesCompound(node.ancestors[position], parts[i]));
      if (position < 0) return false;
    }
    return true;
  })).length;
}

const stripComments = (code, kind) => kind === 'py' ? code.replace(/#.*$/gm, '') :
  code.replace(/<!--[\s\S]*?-->/g, '').replace(/\/\*[\s\S]*?\*\//g, '');

function ruleCheck(problem, code) {
  const clean = stripComments(code, problem.kind), nodes = parseHtml(clean);
  return problem.checks.map(c => ({
    label: c.label,
    passed: c.type === 's' ? countMatches(nodes, c.pattern) >= c.min : new RegExp(c.pattern, c.flags).test(clean)
  }));
}

// problem = row from the database (tests/checks still JSON text). Returns the verdict and per-test results.
async function judge(problem, code, publicOnly) {
  if (typeof code !== 'string' || !code.trim()) return { verdict: 'Wrong Answer', message: 'Write some code first.', results: [] };
  if (code.length > MAX_CODE_LENGTH) return { verdict: 'Wrong Answer', message: 'Code is too long (20,000 characters maximum).', results: [] };
  if (problem.kind !== 'js') {
    const results = ruleCheck({ ...problem, checks: JSON.parse(problem.checks) }, code);
    return { verdict: results.every(r => r.passed) ? 'Accepted' : 'Wrong Answer', ruleBased: true, results };
  }
  if (!IDENTIFIER.test(problem.fn)) return { verdict: 'Wrong Answer', message: 'Problem is misconfigured.', results: [] };
  const allTests = JSON.parse(problem.tests), tests = publicOnly ? allTests.slice(0, PUBLIC_TESTS) : allTests;
  const reply = await runWorker(problem, code, tests);
  if (reply.timedOut) return { verdict: 'Time Limit Exceeded', results: [] };
  if (reply.error) return { verdict: 'Wrong Answer', message: reply.error.slice(0, 200), results: [] };
  const parsed = JSON.parse(reply.raw);
  if (parsed.missing) return { verdict: 'Wrong Answer', message: `Function ${problem.fn} was not found.`, results: [] };
  const unordered = UNORDERED_RESULT_IDS.includes(problem.id);
  const results = parsed.out.map((r, i) => ({
    passed: r.ok && normalise(r.value, unordered) === normalise(JSON.stringify(tests[i][1]), unordered),
    // Only the public tests reveal values; hidden tests show pass/fail only.
    ...(i < PUBLIC_TESTS ? { got: r.ok ? r.value : `Error: ${r.error}`, expected: JSON.stringify(tests[i][1]) } : {})
  }));
  return { verdict: results.every(r => r.passed) ? 'Accepted' : 'Wrong Answer', results };
}

// Similarity 0..1 from Levenshtein distance on whitespace-free code (plagiarism check).
function similarity(a, b) {
  const x = a.replace(/\s+/g, '').slice(0, 3000), y = b.replace(/\s+/g, '').slice(0, 3000);
  if (!x.length && !y.length) return 1;
  let prev = Array.from({ length: y.length + 1 }, (_, i) => i);
  for (let i = 1; i <= x.length; i++) {
    const cur = [i];
    for (let j = 1; j <= y.length; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (x[i - 1] === y[j - 1] ? 0 : 1));
    prev = cur;
  }
  return 1 - prev[y.length] / Math.max(x.length, y.length);
}

module.exports = { judge, similarity, ruleCheck, PUBLIC_TESTS };
