/* app.js - the HTTP server: static files + REST API. Built on Node's http module (no dependencies). */
'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const sec = require('./security');
const sc = require('./scoring');
const { openDb, transaction } = require('./db');
const { judge, similarity, PUBLIC_TESTS } = require('./judge');
const { HttpError } = sec;

const MAX_BODY_BYTES = 100 * 1024, MAX_FAILED_LOGINS = 5, LOCK_MS = 60 * 1000, SIMILARITY_FLAG = 0.9;
const TEAM_NAME = /^[A-Za-z0-9 ]{3,22}$/;
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript', '.jpg': 'image/jpeg', '.png': 'image/png', '.svg': 'image/svg+xml', '.txt': 'text/plain' };

function createApp({ dbFile = ':memory:', demo = false, publicDir, secureCookies = false, tzMinutes = 330, limits = {} } = {}) {
  const authLimit = limits.auth || 30, judgeLimit = limits.judge || 40;   // requests per minute per IP
  const db = openDb({ file: dbFile, demo, tzMinutes });
  const allowed = sec.createLimiter();
  const today = (daysAgo = 0) => sc.dateString(daysAgo, new Date(), tzMinutes);

  /* ---------- helpers ---------- */
  const requireText = (value, label, max = 200) => {
    if (typeof value !== 'string' || !value.trim() || value.length > max) throw new HttpError(400, `${label} is required.`);
    return value.trim();
  };
  const solvedByDifficulty = userId => {
    const out = {};
    db.prepare(`SELECT p.difficulty AS d, COUNT(*) AS n FROM solves s JOIN problems p ON p.id = s.problem_id WHERE s.user_id = ? GROUP BY p.difficulty`)
      .all(userId).forEach(r => { out[r.d] = r.n; });
    return out;
  };
  const getProblem = id => {
    const problem = db.prepare('SELECT * FROM problems WHERE id = ?').get(Number(id));
    if (!problem) throw new HttpError(404, 'Problem not found.');
    return problem;
  };
  const dailyId = () => sc.pickDaily(db.prepare('SELECT id, kind FROM problems').all(), new Date(), tzMinutes).id;
  const canOpen = (user, problem) => problem.id === dailyId() || sc.isUnlocked(problem.difficulty, solvedByDifficulty(user.id));
  const leaderboard = () => {
    const rows = db.prepare(`SELECT u.id AS user_id, t.id AS team_id, t.name AS team_name, t.avatar FROM users u JOIN teams t ON t.id = u.team_id`).all();
    const solves = db.prepare('SELECT user_id, points, solved_date FROM solves').all();
    const byUser = new Map();
    solves.forEach(s => { const e = byUser.get(s.user_id) || { points: 0, dates: [] }; e.points += s.points; e.dates.push(s.solved_date); byUser.set(s.user_id, e); });
    return sc.buildLeaderboard(rows.map(r => ({ ...r, ...(byUser.get(r.user_id) || { points: 0, dates: [] }) })), new Date(), tzMinutes);
  };
  const userSummary = user => {
    const solves = db.prepare('SELECT points, solved_date FROM solves WHERE user_id = ?').all(user.id);
    const team = user.team_id ? db.prepare('SELECT id, name, avatar FROM teams WHERE id = ?').get(user.team_id) : null;
    return { id: user.id, name: user.name, team, score: solves.reduce((s, r) => s + r.points, 0), solved: solves.length,
      streak: sc.streakDays(solves.map(r => r.solved_date), new Date(), tzMinutes) };
  };
  const rankOfTeam = teamId => (leaderboard().find(t => t.id === teamId) || {}).rank || 0;

  /* ---------- sessions ---------- */
  function startSession(res, userId) {
    const token = sec.newToken();
    db.prepare('INSERT INTO sessions VALUES (?,?,?)').run(sec.tokenHash(token), userId, Date.now() + sec.SESSION_MINUTES * 60000);
    res.setHeader('Set-Cookie', sec.sessionCookie(token, secureCookies));
  }
  function sessionUser(req) {
    const token = sec.parseCookies(req.headers.cookie)[sec.COOKIE_NAME];
    if (!token) return null;
    const hash = sec.tokenHash(token);
    const row = db.prepare('SELECT u.*, s.expires_at FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?').get(hash);
    if (!row || row.expires_at < Date.now()) { db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(hash); return null; }
    db.prepare('UPDATE sessions SET expires_at = ? WHERE token_hash = ?').run(Date.now() + sec.SESSION_MINUTES * 60000, hash);  // idle timeout
    return row;
  }

  /* ---------- routes: [method, path pattern, needs login, handler] ---------- */
  const routes = [
    ['POST', '/api/auth/register', false, async ({ body, res }) => {
      const name = requireText(body.name, 'Username', 40);
      const error = sec.validateName(name) || sec.validatePassword(body.password, name);
      if (error) throw new HttpError(400, error);
      if (db.prepare('SELECT 1 FROM users WHERE name = ?').get(name)) throw new HttpError(409, 'That username is already taken.');
      const id = db.prepare('INSERT INTO users (name, password_hash, created_at) VALUES (?,?,?)').run(name, await sec.hashPassword(body.password), Date.now()).lastInsertRowid;
      startSession(res, id);
      return [201, { user: userSummary(db.prepare('SELECT * FROM users WHERE id = ?').get(id)) }];
    }],
    ['POST', '/api/auth/login', false, async ({ body, res }) => {
      const fail = new HttpError(401, 'Wrong username or password.');
      const name = typeof body.name === 'string' ? body.name.trim() : '', password = typeof body.password === 'string' ? body.password.slice(0, 64) : '';
      const user = db.prepare('SELECT * FROM users WHERE name = ?').get(name);
      if (!user || !user.password_hash) { await sec.verifyPassword(password, sec.DUMMY_HASH); throw fail; }   // same work, same message
      if (user.locked_until > Date.now()) throw new HttpError(429, `Too many attempts. Try again in ${Math.ceil((user.locked_until - Date.now()) / 1000)} seconds.`);
      if (!(await sec.verifyPassword(password, user.password_hash))) {
        const failed = user.failed_logins + 1;
        db.prepare('UPDATE users SET failed_logins = ?, locked_until = ? WHERE id = ?').run(failed >= MAX_FAILED_LOGINS ? 0 : failed, failed >= MAX_FAILED_LOGINS ? Date.now() + LOCK_MS : 0, user.id);
        throw fail;
      }
      db.prepare('UPDATE users SET failed_logins = 0, locked_until = 0 WHERE id = ?').run(user.id);
      startSession(res, user.id);
      return { user: userSummary(user) };
    }],
    ['POST', '/api/auth/logout', false, ({ req, res }) => {
      const token = sec.parseCookies(req.headers.cookie)[sec.COOKIE_NAME];
      if (token) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sec.tokenHash(token));
      res.setHeader('Set-Cookie', sec.sessionCookie('', secureCookies, 0));
      return { ok: true };
    }],
    ['GET', '/api/me', true, ({ user }) => ({ user: userSummary(user) })],
    ['GET', '/api/me/calendar', true, ({ user }) => {
      const counts = {};
      db.prepare('SELECT solved_date AS d, COUNT(*) AS n FROM solves WHERE user_id = ? GROUP BY solved_date').all(user.id).forEach(r => { counts[r.d] = r.n; });
      return { days: Array.from({ length: 98 }, (_, i) => { const date = today(97 - i); return { date, count: counts[date] || 0 }; }) };
    }],

    ['GET', '/api/problems', true, ({ user, query }) => {
      const solved = new Set(db.prepare('SELECT problem_id FROM solves WHERE user_id = ?').all(user.id).map(r => r.problem_id));
      const counts = solvedByDifficulty(user.id), daily = dailyId(), q = (query.get('q') || '').toLowerCase();
      const list = db.prepare('SELECT id, title, difficulty, tag, kind FROM problems ORDER BY id').all()
        .filter(p => (!query.get('difficulty') || p.difficulty === query.get('difficulty')) && (!query.get('tag') || p.tag === query.get('tag')) &&
                     (!q || `${p.title} ${p.tag}`.toLowerCase().includes(q)))
        .map(p => ({ ...p, solved: solved.has(p.id), locked: p.id !== daily && !sc.isUnlocked(p.difficulty, counts), daily: p.id === daily }));
      return { problems: list, tags: db.prepare('SELECT DISTINCT tag FROM problems ORDER BY tag').all().map(r => r.tag) };
    }],
    ['GET', '/api/problems/daily', true, ({ user }) => problemView(user, getProblem(dailyId()))],
    ['GET', '/api/problems/:id', true, ({ user, params }) => problemView(user, getProblem(params.id))],
    ['POST', '/api/problems/:id/run', true, async ({ user, params, body }) => {
      const problem = getProblem(params.id);
      if (!canOpen(user, problem)) throw new HttpError(403, 'This problem is locked.');
      return await judge(problem, body.code, true);
    }],
    ['POST', '/api/problems/:id/submit', true, async ({ user, params, body }) => {
      const problem = getProblem(params.id);
      if (!canOpen(user, problem)) throw new HttpError(403, 'This problem is locked.');
      const code = typeof body.code === 'string' ? body.code : '';
      const verdict = await judge(problem, code, false);
      // The server measures the time itself (from when the problem was opened); the browser cannot change it.
      const attempt = db.prepare('SELECT started_at FROM attempts WHERE user_id = ? AND problem_id = ?').get(user.id, problem.id);
      const seconds = Math.max(0, Math.floor((Date.now() - (attempt ? attempt.started_at : Date.now())) / 1000));
      const accepted = verdict.verdict === 'Accepted';
      let similar = null;
      if (accepted) {
        db.prepare(`SELECT user_id, code FROM submissions WHERE problem_id = ? AND verdict = 'Accepted' AND user_id != ? ORDER BY id DESC LIMIT 20`)
          .all(problem.id, user.id).forEach(other => {
            const score = similarity(code, other.code);
            if (score >= SIMILARITY_FLAG && (!similar || score > similar.score)) similar = { userId: other.user_id, score };
          });
      }
      db.prepare('INSERT INTO submissions (user_id, problem_id, verdict, passed, total, code, similar_to, similarity, created_at) VALUES (?,?,?,?,?,?,?,?,?)')
        .run(user.id, problem.id, verdict.verdict, verdict.results.filter(r => r.passed).length, verdict.results.length, code.slice(0, 20000),
             similar ? similar.userId : null, similar ? similar.score : null, Date.now());
      let points = 0, firstSolve = false;
      const rankBefore = user.team_id ? rankOfTeam(user.team_id) : 0;
      if (accepted) {
        points = sc.solveScore(problem.difficulty, seconds);
        // INSERT OR IGNORE: the (user, problem) key makes only the FIRST accepted submission count.
        firstSolve = db.prepare('INSERT OR IGNORE INTO solves VALUES (?,?,?,?,?)').run(user.id, problem.id, seconds, points, today()).changes === 1;
        if (!firstSolve) points = 0;
      }
      return { ...verdict, seconds, points, firstSolve, rankBefore, rankAfter: user.team_id ? rankOfTeam(user.team_id) : 0,
        user: userSummary(user),
        warning: similar ? `Your solution is ${Math.round(similar.score * 100)}% similar to another player's. Plagiarism flag recorded.` : undefined };
    }],

    ['GET', '/api/teams', true, () => ({ teams: db.prepare(`SELECT t.id, t.name, t.avatar, COUNT(u.id) AS members FROM teams t LEFT JOIN users u ON u.team_id = t.id GROUP BY t.id ORDER BY t.name`).all(),
      minSize: sc.MIN_TEAM_SIZE, maxSize: sc.MAX_TEAM_SIZE })],
    ['POST', '/api/teams', true, ({ user, body }) => {
      const name = requireText(body.name, 'Squad name', 40).replace(/\s+/g, ' ');
      if (!TEAM_NAME.test(name)) throw new HttpError(400, 'Squad name: 3-22 letters, numbers or spaces.');
      const avatar = Number.isInteger(body.avatar) && body.avatar >= 0 && body.avatar < 6 ? body.avatar : 0;
      if (db.prepare('SELECT 1 FROM teams WHERE name = ?').get(name)) throw new HttpError(409, 'That squad name is taken.');
      const id = transaction(db, () => {
        const teamId = db.prepare('INSERT INTO teams (name, avatar, created_at) VALUES (?,?,?)').run(name, avatar, Date.now()).lastInsertRowid;
        db.prepare('UPDATE users SET team_id = ? WHERE id = ?').run(teamId, user.id);
        db.prepare('DELETE FROM teams WHERE id NOT IN (SELECT DISTINCT team_id FROM users WHERE team_id IS NOT NULL)').run();
        return teamId;
      });
      return [201, { team: { id, name, avatar } }];
    }],
    ['POST', '/api/teams/leave', true, ({ user }) => {
      transaction(db, () => {
        db.prepare('UPDATE users SET team_id = NULL WHERE id = ?').run(user.id);
        db.prepare('DELETE FROM teams WHERE id NOT IN (SELECT DISTINCT team_id FROM users WHERE team_id IS NOT NULL)').run();
      });
      return { ok: true };
    }],
    ['POST', '/api/teams/:id/join', true, ({ user, params }) => {
      transaction(db, () => {
        const team = db.prepare('SELECT id FROM teams WHERE id = ?').get(Number(params.id));
        if (!team) throw new HttpError(404, 'Squad not found.');
        if (db.prepare('SELECT COUNT(*) AS n FROM users WHERE team_id = ?').get(team.id).n >= sc.MAX_TEAM_SIZE) throw new HttpError(409, 'That squad is full.');
        db.prepare('UPDATE users SET team_id = ? WHERE id = ?').run(team.id, user.id);
        db.prepare('DELETE FROM teams WHERE id NOT IN (SELECT DISTINCT team_id FROM users WHERE team_id IS NOT NULL)').run();
      });
      return { ok: true };
    }],
    ['GET', '/api/leaderboard', true, () => ({ teams: leaderboard(), updatedAt: Date.now() })],
    ['GET', '/api/health', false, () => ({ status: 'ok' })]
  ].map(([method, pattern, auth, handler]) => ({
    method, auth, handler, keys: [...pattern.matchAll(/:(\w+)/g)].map(m => m[1]),
    regex: new RegExp('^' + pattern.replace(/:\w+/g, '([^/]+)') + '$')
  }));

  // What the browser may see about a problem: statement, public tests and starter code. Never hidden tests.
  function problemView(user, problem) {
    if (!canOpen(user, problem)) throw new HttpError(403, 'Solve 5 problems of the previous level to unlock this one.');
    db.prepare('INSERT OR IGNORE INTO attempts VALUES (?,?,?)').run(user.id, problem.id, Date.now());
    const tests = JSON.parse(problem.tests), checks = JSON.parse(problem.checks);
    return { problem: {
      id: problem.id, title: problem.title, difficulty: problem.difficulty, tag: problem.tag, kind: problem.kind,
      fn: problem.fn, params: problem.params, description: problem.description, starter: problem.starter,
      timeLimitMinutes: sc.TIME_LIMIT_MINUTES[problem.difficulty],
      publicTests: tests.slice(0, PUBLIC_TESTS).map(([args, expected]) => ({ args, expected })),
      hiddenTestCount: Math.max(0, tests.length - PUBLIC_TESTS), rules: checks.map(c => c.label),
      solved: Boolean(db.prepare('SELECT 1 FROM solves WHERE user_id = ? AND problem_id = ?').get(user.id, problem.id))
    } };
  }

  /* ---------- request handling ---------- */
  function readBody(req) {
    return new Promise((resolve, reject) => {
      const chunks = []; let size = 0;
      req.on('data', chunk => { size += chunk.length; if (size > MAX_BODY_BYTES) { reject(new HttpError(413, 'Request too large.')); req.destroy(); } else chunks.push(chunk); });
      req.on('end', () => {
        if (!size) return resolve({});
        if (!/^application\/json/.test(req.headers['content-type'] || '')) return reject(new HttpError(415, 'Send JSON.'));
        try { const body = JSON.parse(Buffer.concat(chunks).toString('utf8')); resolve(body && typeof body === 'object' && !Array.isArray(body) ? body : {}); }
        catch (error) { reject(new HttpError(400, 'Invalid JSON.')); }
      });
      req.on('error', reject);
    });
  }

  const send = (res, status, data) => {
    const text = JSON.stringify(data);
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...(res.getHeader('Set-Cookie') ? { 'Set-Cookie': res.getHeader('Set-Cookie') } : {}) });
    res.end(text);
  };

  async function handleApi(req, res, url) {
    if (!sec.sameOrigin(req)) throw new HttpError(403, 'Cross-site request blocked.');
    const route = routes.map(r => ({ r, m: url.pathname.match(r.regex) })).find(x => x.m && x.r.method === req.method);
    if (!route) throw new HttpError(url.pathname.startsWith('/api/') && routes.some(r => r.regex.test(url.pathname)) ? 405 : 404, 'Not found.');
    const ip = req.socket.remoteAddress || 'unknown';
    const isAuthRoute = url.pathname.startsWith('/api/auth/'), isJudge = /\/(run|submit)$/.test(url.pathname);
    if (isAuthRoute && !allowed(`auth:${ip}`, authLimit, 60000)) throw new HttpError(429, 'Too many requests. Slow down.');
    if (isJudge && !allowed(`judge:${ip}`, judgeLimit, 60000)) throw new HttpError(429, 'Too many runs. Wait a moment.');
    const user = sessionUser(req);
    if (route.r.auth && !user) throw new HttpError(401, 'Please log in.');
    const params = {}; route.r.keys.forEach((k, i) => { params[k] = route.m[i + 1]; });
    const body = req.method === 'GET' ? {} : await readBody(req);
    const result = await route.r.handler({ req, res, user, params, body, query: url.searchParams });
    return Array.isArray(result) ? result : [200, result];
  }

  function serveStatic(req, res, url) {
    if (!publicDir || !['GET', 'HEAD'].includes(req.method)) throw new HttpError(404, 'Not found.');
    let file = path.resolve(publicDir, '.' + decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname));
    if (file !== path.resolve(publicDir) && !file.startsWith(path.resolve(publicDir) + path.sep)) throw new HttpError(403, 'Forbidden.');  // path traversal guard
    if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) throw new HttpError(404, 'Not found.');
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
    fs.createReadStream(file).pipe(res);
  }

  const server = http.createServer(async (req, res) => {
    Object.entries(sec.SECURITY_HEADERS).forEach(([k, v]) => res.setHeader(k, v));
    try {
      const url = new URL(req.url, 'http://localhost');
      if (url.pathname.startsWith('/api/')) { const [status, data] = await handleApi(req, res, url); send(res, status, data); }
      else serveStatic(req, res, url);
    } catch (error) {
      const status = error instanceof HttpError ? error.status : 500;
      if (status === 500) console.error(error);
      if (!res.headersSent) send(res, status, { error: status === 500 ? 'Server error.' : error.message });
    }
  });
  return { server, db };
}

module.exports = { createApp };
