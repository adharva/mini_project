/* scoring.js - points, streaks, daily problem and leaderboard rules. TeamScore = sum(MemberScores) + StreakBonus. */
'use strict';
const POINTS = { Easy: 10, Medium: 20, Hard: 30 };
const TIME_LIMIT_MINUTES = { Easy: 10, Medium: 20, Hard: 25 };
const STREAK_BONUS_PER_DAY = 2, MAX_STREAK_BONUS_DAYS = 7, SOLVES_TO_UNLOCK = 5;
const MIN_TEAM_SIZE = 3, MAX_TEAM_SIZE = 4;

function speedBonus(seconds, difficulty) {
  if (seconds > TIME_LIMIT_MINUTES[difficulty] * 60) return 0;
  return seconds < 300 ? 5 : seconds < 900 ? 2 : 0;
}
const solveScore = (difficulty, seconds) => POINTS[difficulty] + speedBonus(seconds, difficulty);

// Calendar date (YYYY-MM-DD) in the configured time zone, "daysAgo" days back.
function dateString(daysAgo = 0, now = new Date(), tzMinutes = 330) {
  return new Date(now.getTime() + tzMinutes * 60000 - daysAgo * 864e5).toISOString().slice(0, 10);
}

// Consecutive days ending today (or yesterday if nothing is solved yet today).
function streakDays(dates, now = new Date(), tzMinutes = 330) {
  const days = new Set(dates);
  let offset = days.has(dateString(0, now, tzMinutes)) ? 0 : 1, count = 0;
  while (days.has(dateString(offset, now, tzMinutes))) { count++; offset++; }
  return count;
}

// Same daily problem for everybody, rotating through the executed (JavaScript) problems.
function pickDaily(problems, now = new Date(), tzMinutes = 330) {
  const pool = problems.filter(p => p.kind === 'js').sort((a, b) => a.id - b.id);
  return pool[Math.floor(Date.parse(dateString(0, now, tzMinutes)) / 864e5) % pool.length];
}

const isUnlocked = (difficulty, solvedByDifficulty) =>
  difficulty === 'Easy' || (solvedByDifficulty[difficulty === 'Medium' ? 'Easy' : 'Medium'] || 0) >= SOLVES_TO_UNLOCK;

// rows: [{ team_id, team_name, avatar, user_id, points, dates:[...] }] one per member
function buildLeaderboard(members, now = new Date(), tzMinutes = 330) {
  const teams = new Map();
  members.forEach(m => {
    const team = teams.get(m.team_id) || { id: m.team_id, name: m.team_name, avatar: m.avatar, members: 0, solves: 0, solveScore: 0, streakBonus: 0 };
    team.members++; team.solves += m.dates.length; team.solveScore += m.points;
    team.streakBonus += Math.min(streakDays(m.dates, now, tzMinutes), MAX_STREAK_BONUS_DAYS) * STREAK_BONUS_PER_DAY;
    teams.set(m.team_id, team);
  });
  return [...teams.values()].map(t => ({ ...t, score: t.solveScore + t.streakBonus, forming: t.members < MIN_TEAM_SIZE }))
    .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name)).map((t, i) => ({ rank: i + 1, ...t }));
}

module.exports = { POINTS, TIME_LIMIT_MINUTES, MIN_TEAM_SIZE, MAX_TEAM_SIZE, SOLVES_TO_UNLOCK, speedBonus, solveScore,
  dateString, streakDays, pickDaily, isUnlocked, buildLeaderboard };
