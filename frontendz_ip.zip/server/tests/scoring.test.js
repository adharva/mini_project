'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const sc = require('../src/scoring');
const NOW = new Date('2026-06-15T10:00:00Z');

test('speed bonus and points', () => {
  assert.equal(sc.solveScore('Easy', 100), 15);
  assert.equal(sc.solveScore('Easy', 700), 10);       // past the 10 minute limit
  assert.equal(sc.solveScore('Medium', 600), 22);
  assert.equal(sc.solveScore('Hard', 1000), 30);
});
test('streaks', () => {
  const d = n => sc.dateString(n, NOW);
  assert.equal(sc.streakDays([d(0), d(1), d(2)], NOW), 3);
  assert.equal(sc.streakDays([d(0), d(2)], NOW), 1);
  assert.equal(sc.streakDays([d(1)], NOW), 1);
  assert.equal(sc.streakDays([d(3)], NOW), 0);
});
test('dates follow the configured time zone (IST vs UTC)', () => {
  const lateUtc = new Date('2026-06-15T20:00:00Z');   // already 15 Jun 21:30 in India... and next day after 18:30 UTC
  assert.equal(sc.dateString(0, lateUtc, 330), '2026-06-16');
  assert.equal(sc.dateString(0, lateUtc, 0), '2026-06-15');
});
test('leaderboard ranking and forming squads', () => {
  const rows = [
    { team_id: 1, team_name: 'A', avatar: 0, points: 50, dates: [] }, { team_id: 1, team_name: 'A', avatar: 0, points: 0, dates: [] },
    { team_id: 2, team_name: 'B', avatar: 1, points: 60, dates: [] }];
  const board = sc.buildLeaderboard(rows, NOW);
  assert.deepEqual(board.map(t => t.name), ['B', 'A']);
  assert.equal(board[1].forming, true);
});
test('unlock rule', () => {
  assert.ok(sc.isUnlocked('Easy', {}));
  assert.ok(!sc.isUnlocked('Medium', { Easy: 4 }));
  assert.ok(sc.isUnlocked('Medium', { Easy: 5 }));
  assert.ok(!sc.isUnlocked('Hard', { Medium: 4 }));
});
