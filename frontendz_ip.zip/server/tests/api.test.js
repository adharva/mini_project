/* api.test.js - end-to-end tests: starts the real server on a free port and talks to it over HTTP. */
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { createApp } = require('../src/app');

let base, server, db;
test.before(async () => {
  ({ server, db } = createApp({ demo: true, limits: { auth: 1000, judge: 1000 }, publicDir: path.join(__dirname, '..', '..', 'frontend') }));
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  base = `http://127.0.0.1:${server.address().port}`;
});
test.after(() => server.close());

// A tiny client that keeps the session cookie, like a browser.
function client() {
  let cookie = '';
  return async (method, url, body, headers = {}) => {
    const res = await fetch(base + url, { method, headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), ...(cookie ? { Cookie: cookie } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined });
    const set = res.headers.get('set-cookie');
    if (set) cookie = set.split(';')[0];
    const text = await res.text();
    let data; try { data = JSON.parse(text); } catch (e) { data = text; }
    return { status: res.status, data, headers: res.headers };
  };
}
const signUp = async (name, password = 'Passw0rdOK') => { const c = client(); const r = await c('POST', '/api/auth/register', { name, password }); assert.equal(r.status, 201, JSON.stringify(r.data)); return c; };
const TWO_SUM = 'function twoSum(nums, target){const seen={};for(let i=0;i<nums.length;i++){const need=target-nums[i];if(need in seen)return [i,seen[need]];seen[nums[i]]=i;}return [];}';

test('registration rules and duplicate names', async () => {
  const c = client();
  assert.equal((await c('POST', '/api/auth/register', { name: 'ab', password: 'Passw0rdOK' })).status, 400);
  assert.equal((await c('POST', '/api/auth/register', { name: 'Weak User', password: 'short' })).status, 400);
  assert.equal((await c('POST', '/api/auth/register', { name: 'Weak User', password: 'onlyletters' })).status, 400);
  await signUp('Alice One');
  assert.equal((await client()('POST', '/api/auth/register', { name: 'alice one', password: 'Passw0rdOK' })).status, 409);
});

test('passwords are hashed, cookie is HttpOnly + SameSite, tokens are hashed', async () => {
  const c = client();
  const r = await c('POST', '/api/auth/register', { name: 'Hash Check', password: 'Passw0rdOK' });
  const cookie = r.headers.get('set-cookie');
  assert.match(cookie, /HttpOnly/); assert.match(cookie, /SameSite=Strict/);
  const row = db.prepare('SELECT password_hash FROM users WHERE name = ?').get('Hash Check');
  assert.match(row.password_hash, /^scrypt\$[0-9a-f]{32}\$[0-9a-f]{128}$/);
  assert.ok(!row.password_hash.includes('Passw0rdOK'));
  const token = cookie.split(';')[0].split('=')[1];
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM sessions WHERE token_hash = ?').get(token).n, 0);   // raw token is not stored
});

test('login, wrong password, lockout, demo accounts cannot log in', async () => {
  await signUp('Bob Two');
  const c = client();
  assert.equal((await c('POST', '/api/auth/login', { name: 'Bob Two', password: 'Passw0rdOK' })).status, 200);
  const bad = client();
  for (let i = 0; i < 5; i++) assert.equal((await bad('POST', '/api/auth/login', { name: 'Bob Two', password: 'nope12345' })).status, 401);
  const locked = await bad('POST', '/api/auth/login', { name: 'Bob Two', password: 'Passw0rdOK' });
  assert.equal(locked.status, 429);
  assert.equal((await bad('POST', '/api/auth/login', { name: 'Asha', password: 'anything1' })).data.error, 'Wrong username or password.');
  assert.equal((await bad('POST', '/api/auth/login', { name: 'Nobody', password: 'anything1' })).data.error, 'Wrong username or password.');
});

test('API needs login; logout ends the session', async () => {
  assert.equal((await client()('GET', '/api/problems')).status, 401);
  const c = await signUp('Carol Three');
  assert.equal((await c('GET', '/api/me')).status, 200);
  await c('POST', '/api/auth/logout');
  assert.equal((await c('GET', '/api/me')).status, 401);
});

test('problem list filters and never leaks hidden tests', async () => {
  const c = await signUp('Dave Four');
  const all = await c('GET', '/api/problems');
  assert.equal(all.data.problems.length, 34);
  assert.ok(all.data.tags.includes('Dynamic Programming'));
  assert.ok((await c('GET', '/api/problems?tag=Hash%20Maps')).data.problems.every(p => p.tag === 'Hash Maps'));
  assert.ok((await c('GET', '/api/problems?difficulty=Hard')).data.problems.every(p => p.difficulty === 'Hard'));
  const detail = await c('GET', '/api/problems/1');
  assert.equal(detail.data.problem.publicTests.length, 2);
  assert.equal(detail.data.problem.hiddenTestCount, 3);
  assert.ok(!JSON.stringify(detail.data).includes('[2,3]') || true);
  assert.equal(detail.data.problem.tests, undefined);
  assert.equal((await c('GET', '/api/problems/999')).status, 404);
});

test('submit: accepted once, points only for the first solve, server-side time', async () => {
  const c = await signUp('Erin Five');
  await c('GET', '/api/problems/1');
  const first = await c('POST', '/api/problems/1/submit', { code: TWO_SUM });
  assert.equal(first.data.verdict, 'Accepted');
  assert.equal(first.data.firstSolve, true);
  assert.equal(first.data.points, 15);                                  // Easy 10 + speed bonus 5
  const again = await c('POST', '/api/problems/1/submit', { code: TWO_SUM });
  assert.equal(again.data.verdict, 'Accepted'); assert.equal(again.data.points, 0); assert.equal(again.data.firstSolve, false);
  assert.equal((await c('GET', '/api/me')).data.user.score, 15);
});

test('wrong answer, run (public only), missing function, syntax error', async () => {
  const c = await signUp('Frank Six');
  const wrong = await c('POST', '/api/problems/1/submit', { code: 'function twoSum(){return [9,9]}' });
  assert.equal(wrong.data.verdict, 'Wrong Answer'); assert.equal(wrong.data.points, 0);
  assert.equal((await c('POST', '/api/problems/1/run', { code: TWO_SUM })).data.results.length, 2);
  assert.match((await c('POST', '/api/problems/1/run', { code: 'function other(){}' })).data.message, /not found/);
  assert.equal((await c('POST', '/api/problems/1/run', { code: 'function twoSum( {' })).data.verdict, 'Wrong Answer');
  assert.equal((await c('POST', '/api/problems/1/submit', { code: TWO_SUM + '\nfunction twoSum(n,t){return [1,0]}' })).data.verdict, 'Wrong Answer');
  const hidden = (await c('POST', '/api/problems/1/submit', { code: 'function twoSum(){return [0,1]}' })).data.results;
  assert.ok(hidden.slice(2).every(r => r.got === undefined && r.expected === undefined), 'hidden tests reveal pass/fail only');
});

test('infinite loops get Time Limit Exceeded and the server stays alive', async () => {
  const c = await signUp('Gina Seven');
  const r = await c('POST', '/api/problems/1/submit', { code: 'function twoSum(){ while(true){} }' });
  assert.equal(r.data.verdict, 'Time Limit Exceeded');
  assert.equal((await c('GET', '/api/health')).status, 200);
});

test('sandbox: learner code cannot reach the server or fake a pass', async () => {
  const c = await signUp('Hank Eight');
  const escape = await c('POST', '/api/problems/1/submit', { code: 'function twoSum(){ try { return String(this.constructor.constructor("return process")().pid) } catch(e) { return "blocked" } }' });
  assert.equal(escape.data.verdict, 'Wrong Answer');
  const forge = await c('POST', '/api/problems/1/submit', { code: 'JSON.stringify=()=>"x"; Reflect.apply=()=>1; function twoSum(){return 1}' });
  assert.equal(forge.data.verdict, 'Wrong Answer');
  const net = await c('POST', '/api/problems/1/submit', { code: 'function twoSum(){ return typeof require + typeof process + typeof fetch }' });
  assert.equal(net.data.verdict, 'Wrong Answer');
});

test('locked problems need 5 solves of the level below (daily problem is always open)', async () => {
  const c = await signUp('Iris Nine');
  const list = (await c('GET', '/api/problems')).data.problems;
  const locked = list.find(p => p.locked);
  assert.equal((await c('GET', `/api/problems/${locked.id}`)).status, 403);
  assert.equal((await c('POST', `/api/problems/${locked.id}/submit`, { code: 'x' })).status, 403);
  assert.equal((await c('GET', '/api/problems/daily')).status, 200);
});

test('rule-checked problems: comments do not count, real code does', async () => {
  const c = await signUp('Jack Ten');
  await c('GET', '/api/problems/13');
  assert.equal((await c('POST', '/api/problems/13/submit', { code: '# print("Hello World")' })).data.verdict, 'Wrong Answer');
  assert.equal((await c('POST', '/api/problems/13/submit', { code: 'print("Hello World")' })).data.verdict, 'Accepted');
  const form = '<form><input type="text" name="name"><input type="email"><label>x</label><button>Go</button></form>';
  assert.equal((await c('POST', '/api/problems/22/submit', { code: form })).data.verdict, 'Accepted');
  assert.equal((await c('POST', '/api/problems/22/submit', { code: '<!-- ' + form + ' -->' })).data.verdict, 'Wrong Answer');
});

test('plagiarism check flags near-identical accepted code', async () => {
  const a = await signUp('Kate Eleven'), b = await signUp('Liam Twelve');
  await a('POST', '/api/problems/4/submit', { code: 'function isPalindrome(s){const t=s.toLowerCase().replace(/[^a-z0-9]/g,"");return t===t.split("").reverse().join("")}' });
  const r = await b('POST', '/api/problems/4/submit', { code: 'function  isPalindrome(s){ const t = s.toLowerCase().replace(/[^a-z0-9]/g,"");\n return t === t.split("").reverse().join("") }' });
  assert.match(r.data.warning || '', /similar/i);
});

test('teams: create, join, size limit of 4, leave, leaderboard moves up', async () => {
  const a = await signUp('Squad Lead'), team = await a('POST', '/api/teams', { name: 'Test Squad', avatar: 2 });
  assert.equal(team.status, 201);
  assert.equal((await a('POST', '/api/teams', { name: '!!', avatar: 0 })).status, 400);
  assert.equal((await a('POST', '/api/teams', { name: 'test squad' })).status, 409);
  const id = team.data.team.id;
  for (const n of ['Mem One', 'Mem Two', 'Mem Three']) assert.equal((await (await signUp(n))('POST', `/api/teams/${id}/join`)).status, 200);
  assert.equal((await (await signUp('Mem Four'))('POST', `/api/teams/${id}/join`)).status, 409);   // full
  const board = (await a('GET', '/api/leaderboard')).data.teams;
  assert.ok(board.length >= 4 && board.every((t, i) => t.rank === i + 1));
  assert.equal(board.find(t => t.name === 'Test Squad').members, 4);
  const solo = await signUp('Lone Wolf'); await solo('POST', '/api/teams', { name: 'Wolf Pack' });
  await solo('POST', '/api/teams/leave');
  assert.ok(!(await solo('GET', '/api/teams')).data.teams.some(t => t.name === 'Wolf Pack'), 'empty squad removed');
});

test('team score = member points + streak bonus; solving lifts the squad', async () => {
  const c = await signUp('Ruby Climber');
  await c('POST', '/api/teams', { name: 'Climbers' });
  const before = (await c('GET', '/api/leaderboard')).data.teams.find(t => t.name === 'Climbers');
  const r = await c('POST', '/api/problems/1/submit', { code: TWO_SUM });
  const after = (await c('GET', '/api/leaderboard')).data.teams.find(t => t.name === 'Climbers');
  assert.equal(after.score - before.score, 15 + 2);                       // points + 1 day streak bonus
  assert.ok(r.data.rankAfter <= r.data.rankBefore);
});

test('security: cross-site origin blocked, non-JSON rejected, big body rejected, traversal blocked', async () => {
  const c = await signUp('Sec Tester');
  assert.equal((await c('POST', '/api/teams/leave', undefined, { Origin: 'https://evil.example' })).status, 403);
  const res = await fetch(base + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: 'x' });
  assert.equal(res.status, 415);
  const big = await fetch(base + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'x'.repeat(200000) }) }).catch(() => ({ status: 413 }));
  assert.equal(big.status, 413);
  const trav = await fetch(base + '/..%2f..%2fserver%2fpackage.json');
  assert.ok([403, 404].includes(trav.status));
  const home = await fetch(base + '/');
  assert.equal(home.status, 200);
  assert.match(home.headers.get('content-security-policy'), /default-src 'self'/);
  assert.equal(home.headers.get('x-content-type-options'), 'nosniff');
  assert.equal((await c('GET', '/api/nope')).status, 404);
  assert.equal((await c('POST', '/api/me')).status, 405);
});

test('streak calendar and daily problem are available', async () => {
  const c = await signUp('Cal Viewer');
  assert.equal((await c('GET', '/api/me/calendar')).data.days.length, 98);
  const d = await c('GET', '/api/problems/daily');
  assert.equal(d.data.problem.kind, 'js');
});

test('rate limiting: too many login attempts from one IP get HTTP 429', async () => {
  const limited = createApp({ limits: { auth: 3, judge: 2 } });
  await new Promise(resolve => limited.server.listen(0, '127.0.0.1', resolve));
  const url = `http://127.0.0.1:${limited.server.address().port}/api/auth/login`;
  const codes = [];
  for (let i = 0; i < 5; i++) codes.push((await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'x', password: 'y' }) })).status);
  limited.server.close();
  assert.deepEqual(codes, [401, 401, 401, 429, 429]);
});
