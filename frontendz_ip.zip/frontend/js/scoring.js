/*
 * scoring.js - points, streaks, unlocking and the team leaderboard.
 * TeamScore = sum(MemberScores) + StreakBonus.
 * These are plain functions (no page access), so tests/tests.html can check them.
 */
const POINTS = { Easy: 10, Medium: 20, Hard: 30 };
const TIME_LIMIT_MINUTES = { Easy: 10, Medium: 20, Hard: 25 };
const STREAK_BONUS_PER_DAY = 2;
const MAX_STREAK_BONUS_DAYS = 7;
const PROBLEMS_TO_UNLOCK_NEXT_LEVEL = 5;

// Fast, in-time solves earn a small bonus. Past the time limit there is no bonus.
function speedBonus(seconds, difficulty) {
  if (seconds > TIME_LIMIT_MINUTES[difficulty] * 60) return 0;
  if (seconds < 300) return 5;
  if (seconds < 900) return 2;
  return 0;
}

const solveScore = (problem, seconds) => POINTS[problem.difficulty] + speedBonus(seconds, problem.difficulty);

// user.solved looks like { problemId: [secondsTaken, 'YYYY-MM-DD'] }
function memberScore(user) {
  return Object.keys(user.solved).reduce((sum, id) => {
    const problem = problemById(id);
    return problem ? sum + solveScore(problem, user.solved[id][0]) : sum;
  }, 0);
}

// Consecutive days with at least one solve, ending today (or yesterday if nothing solved yet today).
function streakDays(user, today = new Date()) {
  const days = new Set(Object.values(user.solved).map(entry => entry[1]));
  let offset = days.has(localDate(0, today)) ? 0 : 1;
  let count = 0;
  while (days.has(localDate(offset, today))) { count++; offset++; }
  return count;
}

// Points are given only for the FIRST accepted solve of a problem. Returns the points earned (0 if repeated).
function awardSolve(user, problem, seconds, date = localDate(0)) {
  if (has(user.solved, problem.id)) return 0;
  user.solved[problem.id] = [seconds, date];
  return solveScore(problem, seconds);
}

function solvedCount(user, difficulty) {
  return Object.keys(user.solved).filter(id => {
    const problem = problemById(id);
    return problem && problem.difficulty === difficulty;
  }).length;
}

function isUnlocked(user, problem) {
  if (problem.difficulty === 'Easy') return true;
  const previous = problem.difficulty === 'Medium' ? 'Easy' : 'Medium';
  return solvedCount(user, previous) >= PROBLEMS_TO_UNLOCK_NEXT_LEVEL;
}

// Everyone gets the same daily problem; it rotates through the JavaScript (executed) problems.
function dailyProblem(now = new Date()) {
  const pool = PROBLEMS.filter(problem => problem.kind === 'js');
  const dayNumber = Math.floor(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()) / 864e5);
  return pool[dayNumber % pool.length];
}

function leaderboard(state) {
  return Object.keys(state.teams).map(name => {
    const members = teamMembers(state, name).map(member => state.users[member]);
    const solveTotal = members.reduce((sum, user) => sum + memberScore(user), 0);
    const streakBonus = members.reduce((sum, user) =>
      sum + Math.min(streakDays(user), MAX_STREAK_BONUS_DAYS) * STREAK_BONUS_PER_DAY, 0);
    return {
      name,
      initials: state.teams[name].initials,
      color: TEAM_COLORS[state.teams[name].color % TEAM_COLORS.length],
      members: members.length,
      solves: members.reduce((sum, user) => sum + Object.keys(user.solved).length, 0),
      score: solveTotal + streakBonus
    };
  }).sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
}

const rankOf = (state, teamName) => leaderboard(state).findIndex(team => team.name === teamName) + 1;
