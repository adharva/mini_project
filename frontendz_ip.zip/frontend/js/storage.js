/*
 * storage.js - saved data (users, teams, drafts) plus small shared helpers.
 * Everything is kept in this browser's localStorage because the site is fully static.
 * Who is signed in is NOT stored here; see auth.js (sessionStorage).
 */
const STORAGE_KEY = 'cdd-derby-v2';
const TEAM_COLORS = ['#9db4ff', '#7ee0b0', '#ffd27e', '#ff9db4', '#b49dff', '#7ed4ff'];
const MIN_TEAM_SIZE = 3;
const MAX_TEAM_SIZE = 4;

// Safe lookups: a name such as "constructor" must never match an inherited property.
const has = (object, key) => Object.prototype.hasOwnProperty.call(object, key);

// Escape text before putting it into HTML so user input can never become markup.
const esc = text => String(text).replace(/[&<>"']/g, ch =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));

// Local calendar date (YYYY-MM-DD), "daysAgo" days before "now".
function localDate(daysAgo = 0, now = new Date()) {
  const d = new Date(now);
  d.setDate(d.getDate() - daysAgo);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// Demo squads so the leaderboard is useful on first open. Demo users cannot log in (they have no password).
function seedState() {
  const day = daysAgo => localDate(daysAgo);
  const demo = (team, solved) => ({ team, demo: true, solved });
  return {
    version: 2,
    teams: {
      'Binary Beasts': { initials: 'BB', color: 0 },
      'Code Owls': { initials: 'CO', color: 1 },
      'Pixel Pandas': { initials: 'PP', color: 2 }
    },
    users: {
      Asha: demo('Binary Beasts', { 1: [240, day(0)], 2: [400, day(1)], 3: [500, day(2)], 7: [1300, day(3)] }),
      Ravi: demo('Binary Beasts', { 1: [600, day(0)], 5: [300, day(1)] }),
      Meena: demo('Binary Beasts', { 4: [700, day(1)] }),
      Kiran: demo('Code Owls', { 1: [200, day(0)], 2: [260, day(1)], 4: [900, day(2)], 8: [1000, day(3)] }),
      Zoya: demo('Code Owls', { 2: [700, day(1)] }),
      Dev: demo('Code Owls', { 3: [800, day(2)] }),
      Neha: demo('Pixel Pandas', { 1: [500, day(0)], 3: [300, day(1)] }),
      Omar: demo('Pixel Pandas', { 2: [600, day(1)] }),
      Tara: demo('Pixel Pandas', { 4: [1000, day(3)] })
    }
  };
}

function isValidState(state) {
  return Boolean(state) && state.version === 2 &&
    typeof state.users === 'object' && typeof state.teams === 'object';
}

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (isValidState(saved)) return saved;
  } catch (error) { /* corrupted data: fall back to the seed */ }
  return seedState();
}

function saveState(state) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); return true; }
  catch (error) { return false; }
}

const teamMembers = (state, teamName) =>
  Object.keys(state.users).filter(name => state.users[name].team === teamName);

// Remove squads that have no members left (e.g. after everyone moved away).
function pruneEmptyTeams(state) {
  Object.keys(state.teams).forEach(name => {
    if (teamMembers(state, name).length === 0) delete state.teams[name];
  });
}
