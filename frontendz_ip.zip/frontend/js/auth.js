/*
 * auth.js - sign up, log in, session handling.
 * - Passwords are never stored. We store a random salt + a PBKDF2-SHA256 hash (150,000 rounds).
 * - 5 wrong passwords lock that account for 60 seconds.
 * - The session lives in sessionStorage and expires after 30 minutes without activity.
 * NOTE: this is a static site, so all of this runs in the browser. It protects passwords and
 * blocks casual access, but it is not a replacement for a server-side login.
 */
const Auth = (() => {
  const ITERATIONS = 150000;
  const MAX_FAILED_ATTEMPTS = 5;
  const LOCK_MILLISECONDS = 60 * 1000;
  const IDLE_MILLISECONDS = 30 * 60 * 1000;
  const SESSION_KEY = 'cdd-session';
  const NAME_PATTERN = /^[A-Za-z][A-Za-z0-9 ]{2,19}$/;
  const DUMMY_SALT = '00'.repeat(16);
  const LOGIN_FAILED = 'Wrong username or password.';
  const NO_CRYPTO = 'Secure login needs https or localhost. Open the site with Live Server.';
  const encoder = new TextEncoder();

  const bytesToHex = bytes => Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
  const hexToBytes = hex => Uint8Array.from(hex.match(/../g), pair => parseInt(pair, 16));
  const cryptoReady = () => typeof crypto !== 'undefined' && Boolean(crypto.subtle);

  async function hashPassword(password, saltHex) {
    const key = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits']);
    const bits = await crypto.subtle.deriveBits(
      { name: 'PBKDF2', salt: hexToBytes(saltHex), iterations: ITERATIONS, hash: 'SHA-256' }, key, 256);
    return bytesToHex(new Uint8Array(bits));
  }

  // Compare without stopping at the first different character.
  function safeEqual(a, b) {
    if (a.length !== b.length) return false;
    let difference = 0;
    for (let i = 0; i < a.length; i++) difference |= a.charCodeAt(i) ^ b.charCodeAt(i);
    return difference === 0;
  }

  const validateName = name =>
    NAME_PATTERN.test(name) ? '' : 'Username must be 3-20 characters (letters, numbers, spaces) and start with a letter.';

  function validatePassword(password, name = '') {
    if (password.length < 8) return 'Password must be at least 8 characters.';
    if (password.length > 64) return 'Password must be 64 characters or fewer.';
    if (!/[A-Za-z]/.test(password) || !/\d/.test(password)) return 'Password needs at least one letter and one number.';
    if (name && password.toLowerCase() === name.toLowerCase()) return 'Password cannot be the same as your username.';
    return '';
  }

  async function register(state, name, password) {
    if (!cryptoReady()) return { ok: false, error: NO_CRYPTO };
    const problem = validateName(name) || validatePassword(password, name);
    if (problem) return { ok: false, error: problem };
    if (Object.keys(state.users).some(existing => existing.toLowerCase() === name.toLowerCase())) {
      return { ok: false, error: 'That username is already taken.' };
    }
    const salt = bytesToHex(crypto.getRandomValues(new Uint8Array(16)));
    state.users[name] = {
      team: '', solved: {}, drafts: {},
      auth: { salt, hash: await hashPassword(password, salt), failed: 0, lockUntil: 0 }
    };
    startSession(name);
    return { ok: true };
  }

  async function login(state, name, password) {
    if (!cryptoReady()) return { ok: false, error: NO_CRYPTO };
    const user = has(state.users, name) ? state.users[name] : null;
    if (!user || !user.auth) {            // unknown or demo account: same message and same work as a real one
      await hashPassword(password, DUMMY_SALT);
      return { ok: false, error: LOGIN_FAILED };
    }
    const account = user.auth;
    const now = Date.now();
    if (account.lockUntil > now) {
      return { ok: false, error: `Too many attempts. Try again in ${Math.ceil((account.lockUntil - now) / 1000)} seconds.` };
    }
    if (!safeEqual(await hashPassword(password, account.salt), account.hash)) {
      account.failed++;
      if (account.failed >= MAX_FAILED_ATTEMPTS) { account.failed = 0; account.lockUntil = now + LOCK_MILLISECONDS; }
      return { ok: false, error: LOGIN_FAILED };
    }
    account.failed = 0;
    account.lockUntil = 0;
    startSession(name);
    return { ok: true };
  }

  function startSession(name) {
    sessionStorage.setItem(SESSION_KEY, JSON.stringify({ name, last: Date.now() }));
  }

  // Returns the signed-in username, or '' when nobody is signed in or the session expired.
  function currentUser(state) {
    try {
      const session = JSON.parse(sessionStorage.getItem(SESSION_KEY));
      if (session && Date.now() - session.last < IDLE_MILLISECONDS &&
          has(state.users, session.name) && state.users[session.name].auth) return session.name;
    } catch (error) { /* ignore and sign out below */ }
    logout();
    return '';
  }

  function touch() {
    try {
      const session = JSON.parse(sessionStorage.getItem(SESSION_KEY));
      if (session) { session.last = Date.now(); sessionStorage.setItem(SESSION_KEY, JSON.stringify(session)); }
    } catch (error) { /* ignore */ }
  }

  const logout = () => sessionStorage.removeItem(SESSION_KEY);

  return { register, login, logout, currentUser, touch, validateName, validatePassword };
})();
