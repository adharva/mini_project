/*
 * app.js - ties everything together: routing (URL hash), button actions and events.
 * Screens come from views.js, rules from scoring.js, security from auth.js.
 */
const $ = selector => document.querySelector(selector);
let state = loadState();
const ui = {
  authMode: 'login', filter: { group: 'All', query: '' }, banner: null,
  workId: 0, startedAt: 0, avatar: 0, view: 'login', signedIn: false, welcome: false, timer: 0
};
const NAV_LINKS = [['daily', 'Daily challenge'], ['problems', 'Problems'], ['teams', 'Teams'], ['board', 'Leaderboard'], ['profile', 'Profile']];

/* ---------- Rendering and routing ---------- */
function render() {
  const name = Auth.currentUser(state);
  let view = (location.hash || '#home').slice(1);
  if (!name) view = 'login';
  else if (!has(Views, view) || view === 'login') view = 'home';
  if (view === 'work' && !ui.workId) view = 'problems';

  clearInterval(ui.timer);
  ui.view = view;
  ui.signedIn = Boolean(name);
  document.body.dataset.v = view;
  $('#nav').innerHTML = '<b>CodeDojo Daily</b>' + (name
    ? `<div>${NAV_LINKS.map(([id, text]) => `<a href="#${id}" class="${view === id ? 'on' : ''}">${text}</a>`).join('')}<button class="b" data-a="logout">Log out</button></div>` : '');
  $('#app').innerHTML = Views[view]({ state, name, user: name ? state.users[name] : null, ui });
  if (view === 'work') { startTimer(); updatePreview(); }
  addLetterEffect();
  if (view === 'home' && ui.welcome) { ui.welcome = false; try { $('#dlg').showModal(); } catch (error) { /* ignore */ } }
}
addEventListener('hashchange', render);

function toast(message) {
  const box = $('#toast');
  box.textContent = message;
  box.style.display = 'block';
  clearTimeout(box.hideTimer);
  box.hideTimer = setTimeout(() => { box.style.display = 'none'; }, 4200);
}

// Cinematic letters: each letter of nav links and buttons grows on hover.
function addLetterEffect() {
  document.querySelectorAll('nav a, .b').forEach(el => {
    if (el.dataset.letters || el.children.length) return;
    const text = el.textContent;
    let index = 0;
    el.dataset.letters = 1;
    el.classList.add('cin');
    el.setAttribute('aria-label', text);
    el.innerHTML = '<span class="cw" aria-hidden="true">' + text.split(' ').map(word =>
      '<span class="wd">' + [...word].map(ch => `<span class="l" style="--i:${index++}">${esc(ch)}</span>`).join('') + '</span>').join(' ') + '</span>';
  });
}

function startTimer() {
  const problem = problemById(ui.workId);
  const limit = TIME_LIMIT_MINUTES[problem.difficulty] * 60;
  ui.startedAt = Date.now();
  const tick = () => {
    const box = $('#tm');
    if (!box) return;
    const left = Math.max(0, limit - Math.floor((Date.now() - ui.startedAt) / 1000));
    box.textContent = left ? `${String(Math.floor(left / 60)).padStart(2, '0')}:${String(left % 60).padStart(2, '0')}` : 'Time is up';
    box.className = 'tmr' + (left < 60 ? ' lo' : '');
  };
  tick();
  ui.timer = setInterval(tick, 1000);
}

function updatePreview() {
  const frame = $('#pv');
  if (frame) frame.srcdoc = $('#ed').value;
}

/* ---------- Actions (buttons use data-a="name") ---------- */
function saveDraft(name, problemId, code) {
  const user = state.users[name];
  user.drafts = user.drafts || {};
  user.drafts[problemId] = code;
  saveState(state);
}

function requireSignedIn() {
  state = loadState();                      // always work on the newest saved data
  const name = Auth.currentUser(state);
  if (!name) render();
  return name;
}

const ACTIONS = {
  mode(el) {
    const typedName = $('#nm').value;
    ui.authMode = el.dataset.v;
    render();
    $('#nm').value = typedName;
  },

  async submitAuth() {
    const name = $('#nm').value.trim(), password = $('#pw').value, message = $('#authMsg');
    const fail = text => { message.textContent = text; };
    if (!name || !password) return fail('Enter a username and a password.');
    if (ui.authMode === 'signup' && password !== $('#pw2').value) return fail('Passwords do not match.');
    message.textContent = 'Checking…';
    state = loadState();
    const result = ui.authMode === 'signup' ? await Auth.register(state, name, password) : await Auth.login(state, name, password);
    saveState(state);                       // also saves failed-attempt counters
    if (!result.ok) return fail(result.error);
    ui.welcome = true;
    location.hash = '#home';
    render();
  },

  close() { $('#dlg').close(); },
  logout() { Auth.logout(); ui.workId = 0; location.hash = '#home'; render(); },
  filter(el) { ui.filter.group = el.dataset.v; render(); },

  open(el) {
    const name = requireSignedIn();
    if (!name) return;
    const problem = problemById(el.dataset.id);
    if (!problem) return;
    if (!isUnlocked(state.users[name], problem) && problem.id !== dailyProblem().id) {
      return toast(`Solve ${PROBLEMS_TO_UNLOCK_NEXT_LEVEL} ${problem.difficulty === 'Medium' ? 'Easy' : 'Medium'} problems to unlock ${problem.difficulty}.`);
    }
    ui.workId = problem.id;
    location.hash = '#work';
    render();
  },

  async run() {
    const name = requireSignedIn();
    if (!name) return;
    const problem = problemById(ui.workId), code = $('#ed').value;
    saveDraft(name, problem.id, code);
    $('#out').textContent = 'Running…';
    $('#out').innerHTML = renderOutcome(await evaluate(code, problem, true), problem);
  },

  async submit() {
    const name = requireSignedIn();
    if (!name) return;
    const problem = problemById(ui.workId), code = $('#ed').value;
    saveDraft(name, problem.id, code);
    $('#out').textContent = 'Running…';
    const outcome = await evaluate(code, problem, false);
    $('#out').innerHTML = renderOutcome(outcome, problem);
    if (outcome.verdict !== 'Accepted') return toast(`${outcome.verdict}. Fix your code and submit again.`);

    state = loadState();
    const user = state.users[name];
    const before = user.team ? rankOf(state, user.team) : 0;
    const seconds = Math.min(Math.floor((Date.now() - ui.startedAt) / 1000), TIME_LIMIT_MINUTES[problem.difficulty] * 60 + 1);
    const points = awardSolve(user, problem, seconds);   // only the first accepted solve scores
    saveState(state);
    ui.banner = { title: problem.title, points, seconds, total: memberScore(user), team: user.team, before, rank: user.team ? rankOf(state, user.team) : 0 };
    location.hash = '#problems';
    render();
  },

  join(el) {
    const name = requireSignedIn();
    if (!name) return;
    const team = el.dataset.n;
    if (!has(state.teams, team)) return toast('That squad no longer exists.');
    if (teamMembers(state, team).length >= MAX_TEAM_SIZE) return toast('That squad is full.');
    state.users[name].team = team;
    pruneEmptyTeams(state);
    saveState(state);
    render();
    toast('Joined ' + team);
  },

  avatar(el) { const typed = $('#tn').value; ui.avatar = +el.dataset.i; render(); $('#tn').value = typed; },

  create() {
    const name = requireSignedIn();
    if (!name) return;
    const teamName = $('#tn').value.trim().replace(/\s+/g, ' ');
    if (!/^[A-Za-z0-9 ]{3,22}$/.test(teamName)) return toast('Squad name: 3-22 letters, numbers or spaces.');
    if (has(state.teams, teamName)) return toast('That name is taken.');
    state.teams[teamName] = { initials: teamName.split(' ').map(word => word[0]).join('').slice(0, 2).toUpperCase(), color: ui.avatar };
    state.users[name].team = teamName;
    pruneEmptyTeams(state);
    saveState(state);
    render();
    toast('Squad created');
  }
};

/* ---------- Events ---------- */
document.addEventListener('click', event => {
  Auth.touch();
  const el = event.target.closest('[data-a]');
  if (el && has(ACTIONS, el.dataset.a)) ACTIONS[el.dataset.a](el);
});

document.addEventListener('input', event => {
  if (event.target.id === 'ed') updatePreview();
  if (event.target.id === 'q') {
    ui.filter.query = event.target.value;
    const caret = event.target.selectionStart;
    render();
    $('#q').focus();
    $('#q').setSelectionRange(caret, caret);
  }
});

document.addEventListener('keydown', event => {
  Auth.touch();
  const id = event.target.id;
  if (id === 'ed' && event.key === 'Tab') {                 // Tab inserts two spaces in the editor
    event.preventDefault();
    const box = event.target, start = box.selectionStart;
    box.value = box.value.slice(0, start) + '  ' + box.value.slice(box.selectionEnd);
    box.selectionStart = box.selectionEnd = start + 2;
  }
  if (['nm', 'pw', 'pw2'].includes(id) && event.key === 'Enter') ACTIONS.submitAuth();
});

// Refresh the leaderboard every 5 seconds; sign out after 30 idle minutes.
setInterval(() => {
  if (ui.signedIn && !Auth.currentUser(state)) { toast('Signed out after 30 minutes of inactivity.'); render(); }
  else if (ui.view === 'board') { state = loadState(); render(); }
}, 5000);

render();
