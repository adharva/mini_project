/*
 * problems.js - the challenge list.
 * Each JavaScript row is: [id, title, difficulty, tag, functionName, params, description, tests].
 * A test is [argumentsArray, expectedResult]. The first 2 tests are public, the rest hidden.
 * Python / HTML / CSS rows are built with ruleProblem() and checked by rules (see runner.js).
 */
const ruleProblem = (id, title, difficulty, tag, description, kind, starter, checks) =>
  [id, title, difficulty, tag, '', '', description, [], kind, starter, checks];
const PYTHON_STARTER='# write your code here\n',HTML_STARTER='<!DOCTYPE html>\n<html>\n<head>\n<title>Page</title>\n</head>\n<body>\n  <!-- write your code here -->\n</body>\n</html>\n',CSS_STARTER='<!DOCTYPE html>\n<html>\n<head>\n<style>\n  /* write your CSS here */\n</style>\n</head>\n<body>\n  <h1>Hello</h1>\n  <div class="box">A box</div>\n</body>\n</html>\n';
const PROBLEMS = [
[1,'Two Sum','Easy','Arrays','twoSum','nums, target','Return the indices of the two numbers that add up to the target. Exactly one answer exists.',[[[[2,7,11,15],9],[0,1]],[[[3,2,4],6],[1,2]],[[[3,3],6],[0,1]],[[[1,5,8,3],11],[2,3]],[[[0,4,3,0],0],[0,3]]]],
[2,'Sum of 1 to N','Easy','Loops','sumTo','n','Return the sum of all whole numbers from 1 to n.',[[[5],15],[[1],1],[[10],55],[[100],5050],[[0],0]]],
[3,'Even or Odd','Easy','Basics','evenOdd','n','Return "Even" or "Odd" for the number n.',[[[4],'Even'],[[7],'Odd'],[[0],'Even'],[[-3],'Odd'],[[100],'Even']]],
[4,'Palindrome Check','Easy','Strings','isPalindrome','s','Return true if the string reads the same backwards, ignoring case.',[[['Level'],true],[['hello'],false],[['a'],true],[['Racecar'],true],[['ab'],false]]],
[5,'Reverse a Number','Medium','Math','reverseNumber','n','Return the digits of n in reverse order as a number.',[[[123],321],[[400],4],[[5],5],[[1200],21],[[9081],1809]]],
[6,'Valid Anagram','Medium','Strings','isAnagram','a, b','Return true if both strings use exactly the same letters.',[[['listen','silent'],true],[['abc','abd'],false],[['a','a'],true],[['aab','aba'],true],[['ab','abc'],false]]],
[7,'Primes up to N','Medium','Math','primesUpTo','n','Return an array of all prime numbers up to n.',[[[10],[2,3,5,7]],[[2],[2]],[[1],[]],[[20],[2,3,5,7,11,13,17,19]],[[3],[2,3]]]],
[8,'Fibonacci Series','Medium','Loops','fibonacci','n','Return the first n terms of the Fibonacci series starting 0, 1.',[[[5],[0,1,1,2,3]],[[1],[0]],[[2],[0,1]],[[8],[0,1,1,2,3,5,8,13]],[[0],[]]]],
[9,'Factorial','Medium','Recursion','factorial','n','Return n factorial. factorial(0) is 1.',[[[5],120],[[0],1],[[1],1],[[6],720],[[10],3628800]]],
[10,'Armstrong Number','Medium','Math','isArmstrong','n','Return true if n equals the sum of its digits each raised to the number of digits.',[[[153],true],[[10],false],[[9],true],[[370],true],[[100],false]]],
[11,'Binary Search','Hard','Arrays','binarySearch','arr, target','Return the index of target in a sorted array, or -1.',[[[[1,3,5,7,9],7],3],[[[1,3,5],4],-1],[[[2],2],0],[[[1,2,3,4,5,6],1],0],[[[],1],-1]]],
[12,'Merge Sort','Hard','Arrays','mergeSort','arr','Return a new sorted array using merge sort.',[[[[5,2,9,1]],[1,2,5,9]],[[[]],[]],[[[3]],[3]],[[[2,2,1]],[1,2,2]],[[[9,8,7,6,5]],[5,6,7,8,9]]]],
ruleProblem(13,'Python: Hello World','Easy','Python','Write a Python program that prints Hello World.','py',PYTHON_STARTER,[['Uses print()','r',/print\s*\(/],['Prints the text Hello World','r',/print\s*\(\s*(["'])Hello World\1\s*\)/]]),
ruleProblem(14,'Python: Sum of Two Numbers','Easy','Python','Take two numbers as input and print their sum.','py',PYTHON_STARTER,[['Reads input with input()','r',/input\s*\(/],['Converts with int() or float()','r',/(int|float)\s*\(/],['Adds the numbers','r',/\+/],['Prints the result','r',/print\s*\(/]]),
ruleProblem(15,'Python: Even or Odd','Easy','Python','Find whether a number is even or odd and print the answer.','py',PYTHON_STARTER,[['Uses % 2','r',/%\s*2/],['Uses if and else','r',/\bif\b[\s\S]*\belse\b/],['Shows Even','r',/even/i],['Shows Odd','r',/odd/i]]),
ruleProblem(16,'Python: Swap Two Numbers','Easy','Python','Swap two numbers without a third variable and print them.','py',PYTHON_STARTER,[['Swaps without a third variable','r',/(\w+)\s*,\s*(\w+)\s*=\s*\2\s*,\s*\1|(\w+)\s*=\s*\3\s*\+\s*(\w+)\s*\n\s*\4\s*=\s*\3\s*-\s*\4/],['Prints the swapped values','r',/print\s*\(/]]),
ruleProblem(17,'Python: Factorial with Recursion','Medium','Python','Write def factorial(n) that calls itself to find n factorial.','py','def factorial(n):\n    # write your code here\n',[['Defines factorial(n)','r',/def\s+factorial\s*\(\s*n\s*\)\s*:/],['Has a base case','r',/if\s+n\s*(==|<=|<)\s*[01]/],['Calls itself with n - 1','r',/factorial\s*\(\s*n\s*-\s*1\s*\)/],['Returns a value','r',/return\s+/]]),
ruleProblem(18,'Python: Character Frequency','Medium','Python','Write a function that counts how many times each character appears in a string.','py','def char_freq(s):\n    # write your code here\n',[['Defines a function','r',/def\s+\w+\s*\(/],['Loops over the characters','r',/for\s+\w+\s+in\s+/],['Counts in a dictionary','r',/\{\s*\}|dict\s*\(|Counter|\.get\s*\(/],['Returns the counts','r',/return\s+/]]),
ruleProblem(19,'HTML: Formatted Paragraph','Easy','HTML','Create a paragraph that uses bold, italic and underlined or highlighted text.','web',HTML_STARTER,[['A paragraph (p)','s','p'],['Bold text (b or strong)','s','b, strong'],['Italic text (i or em)','s','i, em'],['Underlined or highlighted text (u or mark)','s','u, mark']]),
ruleProblem(20,'HTML: Insert an Image','Easy','HTML','Insert an image with a source and alt text.','web',HTML_STARTER,[['An image with a src','s','img[src]'],['Alt text on the image','s','img[alt]']]),
ruleProblem(21,'HTML: Create a Hyperlink','Easy','HTML','Create a hyperlink with visible link text.','web',HTML_STARTER,[['A link with an href','s','a[href]'],['Visible link text','r',/<a\b[^>]*href[^>]*>\s*[^<\s][^<]*<\/a>/i]]),
ruleProblem(22,'HTML: Name and Email Form','Easy','HTML','Create a form with name and email fields and a submit button.','web',HTML_STARTER,[['A form','s','form'],['A name field','s','input[name="name"], input[type="text"]'],['An email field','s','input[type="email"]'],['A submit button','s','button, input[type="submit"]'],['A label','s','label']]),
ruleProblem(23,'CSS: Change Text Color','Easy','CSS','Change the color of the heading text using CSS.','web',CSS_STARTER,[['Sets a text color','r',/(^|[;{\s])color\s*:\s*[^;}]+/i]]),
ruleProblem(24,'CSS: Page Background Color','Easy','CSS','Add a background color to the page.','web',CSS_STARTER,[['Styles the body','r',/body\s*\{/i],['Sets a background color','r',/background(-color)?\s*:\s*[^;}]+/i]]),
ruleProblem(25,'CSS: Center a Div','Easy','CSS','Center the box horizontally on the page.','web',CSS_STARTER,[['Sets a width','r',/width\s*:\s*[^;}]+/i],['Centers with margin auto','r',/margin\s*:\s*[^;}]*auto|margin-left\s*:\s*auto/i]]),
ruleProblem(26,'CSS: Bordered Box','Easy','CSS','Create a box with a border and padding.','web',CSS_STARTER,[['Adds a border','r',/border(-width)?\s*:\s*[^;}]+/i],['Adds padding','r',/padding\s*:\s*[^;}]+/i],['A box element (div)','s','div']]),
ruleProblem(27,'HTML: Login Page','Medium','HTML','Create a styled login page with username, password and a button.','web',CSS_STARTER,[['A form','s','form'],['A username or email field','s','input[type="text"], input[type="email"], input[name="username"]'],['A password field','s','input[type="password"]'],['A login button','s','button, input[type="submit"]'],['Some CSS styling','r',/<style[\s\S]*\{/i]]),
ruleProblem(28,'HTML: Registration Form','Medium','HTML','Create a registration form with name, email and password.','web',CSS_STARTER,[['A form','s','form'],['A name field','s','input[type="text"]'],['An email field','s','input[type="email"]'],['A password field','s','input[type="password"]'],['A submit button','s','button, input[type="submit"]'],['Two or more labels','s','label',2]]),
ruleProblem(29,'CSS: Responsive Navigation Menu','Medium','CSS','Create a navigation menu that adapts to small screens.','web',CSS_STARTER,[['A nav element','s','nav'],['At least 3 links','s','nav a',3],['A list of links','s','nav ul li'],['A media query','r',/@media/i]]),
[30,'Contains Duplicate','Easy','Hash Maps','containsDuplicate','nums','Return true if any value appears at least twice.',[[[[1,2,3,1]],true],[[[1,2,3,4]],false],[[[]],false],[[[5,5]],true],[[[9,8,7,9,6]],true]]],
[31,'Move Zeroes','Medium','Two Pointers','moveZeroes','nums','Return a new array with every 0 moved to the end, keeping the other numbers in order.',[[[[0,1,0,3,12]],[1,3,12,0,0]],[[[0]],[0]],[[[1,2]],[1,2]],[[[0,0,1]],[1,0,0]],[[[4,0,5,0,6]],[4,5,6,0,0]]]],
[32,'Climbing Stairs','Medium','Dynamic Programming','climbStairs','n','You can climb 1 or 2 steps at a time. Return the number of distinct ways to reach step n.',[[[1],1],[[2],2],[[3],3],[[5],8],[[10],89]]],
[33,'Best Time to Buy and Sell','Medium','Greedy','maxProfit','prices','Return the best profit from one buy followed by one sell, or 0 if no profit is possible.',[[[[7,1,5,3,6,4]],5],[[[7,6,4,3,1]],0],[[[1]],0],[[[2,4,1]],2],[[[1,2,3,4,5]],4]]],
[34,'House Robber','Hard','Dynamic Programming','rob','nums','Return the most money you can take without robbing two neighbouring houses.',[[[[1,2,3,1]],4],[[[2,7,9,3,1]],12],[[[]],0],[[[5]],5],[[[2,1,1,2]],4]]]
].map(row => ({
  id: row[0], title: row[1], difficulty: row[2], tag: row[3], fn: row[4], params: row[5],
  description: row[6], tests: row[7], kind: row[8] || 'js', starter: row[9], checks: row[10]
}));

// Problems whose answer is a set of indices where the order should not matter.
const UNORDERED_RESULT_IDS = [1];
const problemById = id => PROBLEMS.find(problem => problem.id == id);
