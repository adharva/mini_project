/*
 * views.js - each function turns the current data into the HTML for one screen.
 * ctx = { state, name, user, ui }. Views only build text; app.js handles actions.
 * Everything that comes from a user is passed through esc().
 */
const chip = (text, className = '') => `<span class="t ${className}">${esc(text)}</span>`;
const muted = 'color:var(--mu)';

function renderOutcome(outcome, problem) {
  const colour = outcome.verdict === 'Accepted' ? 'Easy' : 'Hard';
  let html = `<div class="res">${chip(outcome.verdict, colour)} ${esc(outcome.message || '')}</div>`;
  if (outcome.ruleBased) html += '<div class="res" style="font-size:.8rem">Checked against rules. The code is not executed.</div>';
  outcome.results.forEach((result, i) => {
    const label = outcome.ruleBased
      ? esc(result.label)
      : `${i < PUBLIC_TEST_COUNT ? 'Public' : 'Hidden'} test ${i + 1}` +
        (!result.passed && i < PUBLIC_TEST_COUNT
          ? ` - got ${esc(result.got)}, expected ${esc(JSON.stringify(problem.tests[i][1]))}` : '');
    html += `<div class="res">${chip(result.passed ? 'Pass' : 'Fail', result.passed ? 'Easy' : 'Hard')} ${label}</div>`;
  });
  return html;
}

const Views = {
  login: ({ ui }) => {
    const signup = ui.authMode === 'signup';
    return `<div style="text-align:center;padding-top:8vh">
      <div class="chips" style="justify-content:center"><span class="t" style="color:var(--ac)">Daily coding · Teams · Leaderboard</span></div>
      <h1 class="shine">CodeDojo<br>Daily</h1>
      <div class="p neon" style="max-width:420px;margin:0 auto;text-align:left">
        <div class="chips" style="margin-top:0">
          <button class="b${signup ? '' : ' a'}" data-a="mode" data-v="login">Log in</button>
          <button class="b${signup ? ' a' : ''}" data-a="mode" data-v="signup">Sign up</button>
        </div>
        <label for="nm">Username</label>
        <div style="margin:6px 0 14px"><input id="nm" maxlength="20" autocomplete="username"></div>
        <label for="pw">Password</label>
        <div style="margin:6px 0 14px"><input id="pw" type="password" maxlength="64" autocomplete="${signup ? 'new-password' : 'current-password'}"></div>
        ${signup ? `<label for="pw2">Confirm password</label>
        <div style="margin:6px 0 6px"><input id="pw2" type="password" maxlength="64" autocomplete="new-password"></div>
        <p style="${muted};font-size:.8rem;margin:0 0 10px">8+ characters with at least one letter and one number.</p>` : ''}
        <p id="authMsg" role="alert" style="color:#ff9db4;min-height:1.3em;margin:6px 0"></p>
        <button class="b a" style="width:100%" data-a="submitAuth">${signup ? 'Create account' : 'Log in'}</button>
      </div></div>`;
  },

  home: () => `<div style="padding:12vh 0 0;max-width:620px"><h1>One problem.<br>Every night.</h1>
    <p style="${muted};font-size:1.1rem">Solve today’s challenge, run it against test cases, and lift your team up the leaderboard.</p>
    <div class="chips"><a class="b a" href="#daily" style="display:inline-grid;place-items:center">Start today’s challenge</a>
    <a class="b" href="#teams" style="display:inline-grid;place-items:center">Create or join a team</a></div></div>`,

  daily: ({ user }) => {
    const problem = dailyProblem();
    const solved = has(user.solved, problem.id);
    const example = `${esc(JSON.stringify(problem.tests[0][0]))} gives ${esc(JSON.stringify(problem.tests[0][1]))}`;
    return `<div style="padding-top:22vh"><div class="p" style="max-width:660px">
      <div class="chips" style="margin-top:0">${chip('Today’s challenge')}${chip(problem.difficulty, problem.difficulty)}${chip(problem.tag)}${chip(TIME_LIMIT_MINUTES[problem.difficulty] + ' minutes')}</div>
      <h1 style="font-size:2.6rem">${esc(problem.title)}</h1><p style="${muted}">${esc(problem.description)}</p>
      <b>Example</b><p style="${muted};margin:4px 0 16px">${example}</p>
      <button class="b a" data-a="open" data-id="${problem.id}">${solved ? 'Solved. Open again' : 'Open workspace'}</button></div></div>`;
  },

  problems: ({ state, user, ui }) => {
    const { group, query } = ui.filter;
    const order = { Easy: 0, Medium: 1, Hard: 2 };
    const list = PROBLEMS
      .filter(p => (group === 'All' || p.difficulty === group || p.tag === group) &&
                   (!query || (p.title + ' ' + p.tag).toLowerCase().includes(query.toLowerCase())))
      .sort((a, b) => order[a.difficulty] - order[b.difficulty] || a.id - b.id);
    const groups = ['All', 'Easy', 'Medium', 'Hard', ...new Set(PROBLEMS.map(p => p.tag))];
    const easy = solvedCount(user, 'Easy'), medium = solvedCount(user, 'Medium');
    const hint = easy < PROBLEMS_TO_UNLOCK_NEXT_LEVEL ? `Solve ${PROBLEMS_TO_UNLOCK_NEXT_LEVEL - easy} more Easy to unlock Medium`
      : medium < PROBLEMS_TO_UNLOCK_NEXT_LEVEL ? `Solve ${PROBLEMS_TO_UNLOCK_NEXT_LEVEL - medium} more Medium to unlock Hard` : 'All levels unlocked';
    const banner = ui.banner;
    ui.banner = null;
    const bannerHtml = !banner ? '' : `<div class="p" style="margin-bottom:16px;border-color:var(--ok)"><h2>Accepted: ${esc(banner.title)}</h2>
      <p style="margin:0;${muted}">${banner.points ? `+${banner.points} points in ${banner.seconds} seconds.` : 'Already solved earlier, so no new points.'}
      Your score: <b style="color:#fff">${banner.total}</b>.${banner.team
        ? ` Your team is now #${banner.rank}${banner.before && banner.before !== banner.rank ? ` (was #${banner.before})` : ''}.`
        : ' Join a team to score for a squad.'}</p></div>`;
    return `${bannerHtml}<div class="p" style="margin-bottom:16px;display:flex;gap:24px;flex-wrap:wrap">
      <span>Score <b>${memberScore(user)}</b></span><span>Solved <b>${Object.keys(user.solved).length}</b></span>
      <span>Streak <b>${streakDays(user)} days</b></span><span style="${muted}">${hint}</span></div>
      <div class="p"><h2>Problems</h2><label for="q">Search by title or tag</label>
      <div style="margin:6px 0"><input id="q" value="${esc(query)}" placeholder="e.g. strings"></div>
      <div class="chips">${groups.map(g => `<button class="b${group === g ? ' a' : ''}" data-a="filter" data-v="${esc(g)}">${esc(g)}</button>`).join('')}</div>
      ${list.map(p => {
        const status = has(user.solved, p.id) ? 'Solved' : isUnlocked(user, p) ? 'To do' : 'Locked';
        return `<div class="row"><span style="color:${status === 'Solved' ? 'var(--ok)' : 'var(--mu)'}">${status}</span>
          <button class="tl" data-a="open" data-id="${p.id}">${esc(p.title)}</button><span style="${muted}">${esc(p.tag)}</span>${chip(p.difficulty, p.difficulty)}</div>`;
      }).join('') || '<p>No problems match.</p>'}
      <p style="${muted};font-size:.85rem;margin:12px 0 0">${list.length} of ${PROBLEMS.length} shown.</p></div>`;
  },

  work: ({ user, ui }) => {
    const p = problemById(ui.workId);
    const draft = user.drafts && has(user.drafts, p.id) ? user.drafts[p.id] : null;
    const language = p.kind === 'js' ? 'JavaScript' : p.kind === 'py' ? 'Python' : 'HTML and CSS';
    const starter = p.starter || `function ${p.fn}(${p.params}) {\n  // write your code here\n}`;
    const info = p.kind === 'js'
      ? `<b>Function</b><p style="${muted};margin:4px 0 12px"><code>${esc(p.fn)}(${esc(p.params)})</code></p>
         <b>Example</b><p style="${muted};margin:4px 0 12px">${esc(JSON.stringify(p.tests[0][0]))} gives ${esc(JSON.stringify(p.tests[0][1]))}</p>`
      : `<b>Your code is checked for</b><ul style="${muted};margin:4px 0 12px;padding-left:18px">${p.checks.map(c => `<li>${esc(c[0])}</li>`).join('')}</ul>`;
    return `<div class="g3"><div class="p"><div style="display:flex;justify-content:space-between;align-items:center">${chip(p.difficulty, p.difficulty)}<span class="tmr" id="tm">--:--</span></div>
      <h2 style="margin-top:14px;font-size:1.6rem">${esc(p.title)}</h2><p style="${muted}">${esc(p.description)}</p>${info}
      <p style="font-size:.85rem;${muted};margin:0">Time: Easy 10, Medium 20, Hard 25 minutes (no speed bonus after that). ${p.kind === 'js' ? '2 public and 3 hidden tests.' : 'Checked by rules, not executed.'}</p></div>
      <div style="display:grid;gap:16px"><div class="p"><div style="display:flex;gap:10px;margin-bottom:10px">
        <label for="lg" class="sr" style="align-self:center">Language</label><select id="lg" style="max-width:220px" disabled><option>${language}</option></select></div>
        <textarea id="ed" spellcheck="false" aria-label="Code editor">${esc(draft !== null ? draft : starter)}</textarea>
        ${p.kind === 'web' ? '<iframe id="pv" title="Live preview" sandbox="" style="width:100%;height:180px;margin-top:10px;border:0;border-radius:10px;background:#fff"></iframe>' : ''}</div>
      <div class="p"><div class="chips" style="margin-top:0"><button class="b" data-a="run">Run tests</button><button class="b a" data-a="submit">Submit</button></div>
      <div id="out" aria-live="polite" style="${muted}">Run the tests to see results.</div></div></div></div>`;
  },

  teams: ({ state, user, ui }) => `<div class="g2"><div class="p"><h2>Join a squad</h2>
    <p style="${muted};margin:0 0 8px;font-size:.9rem">Squads have ${MIN_TEAM_SIZE} to ${MAX_TEAM_SIZE} members.</p>
    ${Object.keys(state.teams).map(name => {
      const team = state.teams[name], count = teamMembers(state, name).length;
      return `<div class="row tm"><div class="av" style="background:${TEAM_COLORS[team.color % TEAM_COLORS.length]}">${esc(team.initials)}</div>
        <div><b>${esc(name)}</b><div style="font-size:.8rem;${muted}">${count} of ${MAX_TEAM_SIZE} members${count < MIN_TEAM_SIZE ? ' (forming)' : ''}</div></div><span></span>
        ${user.team === name ? '<span class="t Easy">Your squad</span>'
          : `<button class="b" data-a="join" data-n="${esc(name)}" ${count >= MAX_TEAM_SIZE ? 'disabled' : ''}>${count >= MAX_TEAM_SIZE ? 'Full' : 'Join'}</button>`}</div>`;
    }).join('')}</div>
    <div class="p"><h2>Create a squad</h2><label for="tn">Squad name</label><div style="margin:6px 0 14px"><input id="tn" maxlength="22"></div>
    <label>Team avatar</label><div class="chips" id="avs">${TEAM_COLORS.map((color, i) =>
      `<button class="av" aria-label="Avatar ${i + 1}" data-a="avatar" data-i="${i}" style="background:${color};border:${ui.avatar === i ? '3px solid #fff' : '1px solid #fff6'};cursor:pointer"></button>`).join('')}</div>
    <button class="b a" data-a="create">Create squad</button></div></div>`,

  board: ({ state, user }) => `<div class="p"><h2>Team leaderboard</h2>
    <p style="${muted};margin:0 0 10px;font-size:.9rem">Team score = member scores + streak bonus. Refreshes every 5 seconds.</p>
    <div class="row tm" style="border:0;${muted};font-size:.85rem"><span>Rank</span><span>Team</span><span>Solves</span><span>Score</span></div>
    ${leaderboard(state).map((team, i) => `<div class="row tm${team.name === user.team ? ' me' : ''}"><b>${i + 1}</b>
      <span>${esc(team.name)}${team.name === user.team ? ' (you)' : ''}${team.members < MIN_TEAM_SIZE ? ' (forming)' : ''}</span><span>${team.solves}</span><b>${team.score}</b></div>`).join('')}</div>`,

  profile: ({ name, user }) => {
    const perDay = {};
    Object.values(user.solved).forEach(entry => { perDay[entry[1]] = (perDay[entry[1]] || 0) + 1; });
    const cells = [];
    for (let i = 97; i >= 0; i--) {
      const count = perDay[localDate(i)] || 0;
      cells.push(`<i class="${count ? 'l' + Math.min(count, 3) : ''}" title="${localDate(i)}: ${count}"></i>`);
    }
    const levelRow = level => {
      const done = Object.keys(user.solved).filter(id => problemById(id) && problemById(id).difficulty === level).length;
      return `<div style="display:flex;justify-content:space-between;padding:6px 0"><span class="${level}">${level}</span><b>${done} of ${PROBLEMS.filter(p => p.difficulty === level).length}</b></div>`;
    };
    return `<div class="g2"><div class="p"><h2>${esc(name)}</h2><p style="${muted};margin:0 0 14px">${user.team ? esc(user.team) : 'No squad yet'}</p>
      ${['Easy', 'Medium', 'Hard'].map(levelRow).join('')}
      <div style="display:flex;justify-content:space-between;padding:6px 0"><span>Streak</span><b>${streakDays(user)} days</b></div>
      <div style="display:flex;justify-content:space-between;padding:6px 0"><span>Score</span><b>${memberScore(user)}</b></div></div>
      <div class="p"><h2>Streak calendar</h2><p style="${muted};margin:0 0 12px;font-size:.9rem">Last 14 weeks of accepted solutions.</p><div class="heat">${cells.join('')}</div></div></div>`;
  }
};
