/*
 * runner.js - checks a learner's code and returns a verdict.
 * JavaScript problems run inside a Web Worker with a 2.5 second limit and no network access.
 * Python / HTML / CSS problems are checked by rules (comments are ignored first).
 * Verdicts: 'Accepted', 'Wrong Answer', 'Time Limit Exceeded'.
 */
const TIME_LIMIT_MS = 2500;
const PUBLIC_TEST_COUNT = 2;
const MAX_CODE_LENGTH = 20000;

// Source of the worker. Network and loading APIs are removed before learner code runs.
const WORKER_SOURCE = `
  ['fetch', 'XMLHttpRequest', 'WebSocket', 'EventSource', 'importScripts'].forEach(name => {
    try { Object.defineProperty(self, name, { value: undefined, writable: false, configurable: false }); } catch (e) {}
  });
  onmessage = event => {
    const { code, fnName, tests, unordered } = event.data;
    const normalise = value => unordered && Array.isArray(value) ? [...value].sort((a, b) => a - b) : value;
    let fn;
    try { fn = new Function(code + '\\nreturn ' + fnName + ';')(); }
    catch (error) { postMessage({ error: String(error) }); return; }
    if (typeof fn !== 'function') { postMessage({ error: 'Function ' + fnName + ' was not found.' }); return; }
    postMessage({ results: tests.map(([args, expected]) => {
      try {
        const actual = fn(...JSON.parse(JSON.stringify(args)));
        return { passed: JSON.stringify(normalise(actual)) === JSON.stringify(normalise(expected)), got: JSON.stringify(actual) };
      } catch (error) { return { passed: false, got: 'Error: ' + error.message }; }
    }) });
  };`;

function runInWorker(code, problem, tests) {
  return new Promise(resolve => {
    let worker;
    let finished = false;
    const url = URL.createObjectURL(new Blob([WORKER_SOURCE], { type: 'text/javascript' }));
    const finish = result => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      if (worker) worker.terminate();
      URL.revokeObjectURL(url);
      resolve(result);
    };
    const timer = setTimeout(() => finish({ timedOut: true }), TIME_LIMIT_MS);
    try {
      worker = new Worker(url);
      worker.onmessage = event => finish(event.data);
      worker.onerror = event => finish({ error: event.message || 'Runtime error' });
      worker.postMessage({ code, fnName: problem.fn, tests, unordered: UNORDERED_RESULT_IDS.includes(problem.id) });
    } catch (error) {
      finish({ error: 'This browser could not start the safe code runner.' });
    }
  });
}

// Remove comments first so a comment cannot satisfy a rule.
function stripComments(code, kind) {
  if (kind === 'py') return code.replace(/#.*$/gm, '');
  return code.replace(/<!--[\s\S]*?-->/g, '').replace(/\/\*[\s\S]*?\*\//g, '');
}

function runRuleChecks(code, problem) {
  const clean = stripComments(code, problem.kind);
  const doc = new DOMParser().parseFromString(clean, 'text/html');
  return problem.checks.map(([label, type, pattern, minimum = 1]) => ({
    label,
    passed: type === 's' ? doc.querySelectorAll(pattern).length >= minimum : pattern.test(clean)
  }));
}

// publicOnly = true is used by "Run tests"; Submit runs everything including hidden tests.
async function evaluate(code, problem, publicOnly) {
  if (code.length > MAX_CODE_LENGTH) {
    return { verdict: 'Wrong Answer', message: 'Code is too long (limit 20,000 characters).', results: [] };
  }
  if (problem.kind !== 'js') {
    const results = runRuleChecks(code, problem);
    return { verdict: results.every(r => r.passed) ? 'Accepted' : 'Wrong Answer', ruleBased: true, results };
  }
  const tests = publicOnly ? problem.tests.slice(0, PUBLIC_TEST_COUNT) : problem.tests;
  const raw = await runInWorker(code, problem, tests);
  if (raw.timedOut) return { verdict: 'Time Limit Exceeded', results: [] };
  if (raw.error) return { verdict: 'Wrong Answer', message: raw.error, results: [] };
  return { verdict: raw.results.every(r => r.passed) ? 'Accepted' : 'Wrong Answer', results: raw.results };
}
