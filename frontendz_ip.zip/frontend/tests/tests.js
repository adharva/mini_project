/*
 * tests.js - automated checks for scoring, streaks, duplicate submissions, passwords, login lockout
 * and rule-based checking. Open tests/tests.html in a browser to run them.
 * Each test is registered with test(name, function) and uses assert(condition, message).
 */
const makeUser = solved => ({ team: '', solved: solved || {}, drafts: {} });
const NOW = new Date(2026, 5, 15, 12, 0, 0);
const dayStr = n => localDate(n, NOW);

test('speed bonus: 5 under 5 min, 2 under 15 min, none after the time limit', () => {
  assertEqual(speedBonus(100, 'Easy'), 5);
  assertEqual(speedBonus(400, 'Easy'), 2);
  assertEqual(speedBonus(601, 'Easy'), 0);      // Easy limit is 10 minutes
  assertEqual(speedBonus(1000, 'Medium'), 0);
});

test('member score adds difficulty points and bonus', () => {
  const user = makeUser({ 1: [100, dayStr(0)], 7: [1300, dayStr(0)] });   // Easy+5, Medium+0
  assertEqual(memberScore(user), 15 + 20);
});

test('only the first accepted solve earns points', () => {
  const user = makeUser();
  const problem = problemById(1);
  assertEqual(awardSolve(user, problem, 100, dayStr(0)), 15);
  assertEqual(awardSolve(user, problem, 50, dayStr(0)), 0);
  assertEqual(memberScore(user), 15);
});

test('streak counts consecutive days and stops at a gap', () => {
  assertEqual(streakDays(makeUser({ 1: [1, dayStr(0)], 2: [1, dayStr(1)], 3: [1, dayStr(2)] }), NOW), 3);
  assertEqual(streakDays(makeUser({ 1: [1, dayStr(0)], 2: [1, dayStr(2)] }), NOW), 1);
  assertEqual(streakDays(makeUser({ 1: [1, dayStr(1)] }), NOW), 1);       // yesterday still counts
  assertEqual(streakDays(makeUser({ 1: [1, dayStr(3)] }), NOW), 0);
});

test('medium unlocks after 5 easy solves', () => {
  const medium = PROBLEMS.find(p => p.difficulty === 'Medium');
  const four = makeUser({ 1: [1, dayStr(0)], 2: [1, dayStr(0)], 3: [1, dayStr(0)], 4: [1, dayStr(0)] });
  assert(!isUnlocked(four, medium), 'locked with 4 easy');
  four.solved[30] = [1, dayStr(0)];
  assert(isUnlocked(four, medium), 'unlocked with 5 easy');
});

test('team score = member scores + streak bonus, sorted high to low', () => {
  const state = { teams: { A: { initials: 'A', color: 0 }, B: { initials: 'B', color: 1 } }, users: {
    u1: { team: 'A', solved: { 1: [100, localDate(0)] } },          // 15 + streak 1 day (2)
    u2: { team: 'B', solved: { 2: [100, localDate(5)] } } } };       // 15 + no streak
  const board = leaderboard(state);
  assertEqual(board[0].name, 'A');
  assertEqual(board[0].score, 17);
  assertEqual(board[1].score, 15);
});

test('everyone gets the same daily problem', () => {
  assertEqual(dailyProblem(NOW).id, dailyProblem(NOW).id);
  assertEqual(dailyProblem(NOW).kind, 'js');
});

test('password rules', () => {
  assert(Auth.validatePassword('short1') !== '', 'too short');
  assert(Auth.validatePassword('onlyletters') !== '', 'needs a number');
  assert(Auth.validatePassword('12345678') !== '', 'needs a letter');
  assert(Auth.validatePassword('Asha12345', 'asha12345') !== '', 'same as username');
  assertEqual(Auth.validatePassword('goodPass42', 'Asha'), '');
  assert(Auth.validateName('a!') !== '', 'bad username');
  assert(Auth.validateName('constructor') === '', 'valid name format is allowed (lookups use has())');
});

test('rule checks ignore comments', () => {
  const problem = problemById(13);
  assert(runRuleChecks('# print("Hello World")', problem).some(r => !r.passed), 'comment must not pass');
  assert(runRuleChecks('print("Hello World")', problem).every(r => r.passed), 'real code passes');
});

testAsync('register, login, wrong password and lockout', async () => {
  const state = { users: {}, teams: {} };
  assert((await Auth.register(state, 'Tester One', 'strongPass9')).ok, 'register');
  const stored = state.users['Tester One'].auth;
  assert(stored.hash && stored.salt && !JSON.stringify(state).includes('strongPass9'), 'password is not stored');
  assert((await Auth.register(state, 'tester one', 'strongPass9')).ok === false, 'duplicate name (any case)');
  assert((await Auth.login(state, 'Tester One', 'strongPass9')).ok, 'correct password');
  assertEqual(Auth.currentUser(state), 'Tester One');
  Auth.logout();
  assertEqual(Auth.currentUser(state), '');
  for (let i = 0; i < 5; i++) assert((await Auth.login(state, 'Tester One', 'wrongPass1')).ok === false, 'wrong password');
  const locked = await Auth.login(state, 'Tester One', 'strongPass9');
  assert(!locked.ok && /Too many/.test(locked.error), 'account locked even with right password');
  assert((await Auth.login(state, 'Nobody', 'whatever1')).error === 'Wrong username or password.', 'same message for unknown user');
  Auth.logout();
});
