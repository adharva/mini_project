# CodeDojo Daily - Full-Stack Edition

A **static frontend** (plain HTML/CSS/JS, served as static files) plus a **Node.js + SQLite REST backend**
with real accounts, server-side judging and server-side scoring. **No `npm install` needed** - the backend uses
only Node built-ins (`http`, `crypto`, `worker_threads`, `vm`, `node:sqlite`).

## Run it
```
cd server
node --version        # must be 22.5 or newer
npm start             # -> http://localhost:3000
npm test              # 22 automated tests
```
Environment (optional): `PORT`, `DB_FILE`, `TZ_OFFSET_MINUTES` (default 330 = India), `SECURE_COOKIES=1` (behind https), `DEMO=0` (no demo squads).

## Architecture (3 tiers)
```
Browser (static HTML/CSS/JS)  --JSON over HTTP-->  Node.js API (server/src/app.js)  -->  SQLite (server/data/codedojo.db)
                                                    |- security.js  passwords, sessions, rate limit, headers
                                                    |- judge.js + judge-worker.js  sandboxed code runner
                                                    |- scoring.js   points, streaks, leaderboard
                                                    '- db.js        schema, seed, transactions
```

## Database
`users, teams, sessions, problems, attempts, submissions, solves`.
`solves` has PRIMARY KEY (user_id, problem_id): the database itself guarantees points are given only once per
problem per user. `attempts` stores when a user opened a problem, so the **server measures solve time**.

## REST API
| Method | Path | Purpose |
|---|---|---|
| POST | /api/auth/register, /login, /logout | accounts (HttpOnly session cookie) |
| GET | /api/me, /api/me/calendar | profile, score, streak, 98-day heatmap data |
| GET | /api/problems?difficulty=&tag=&q= | filter/search, with solved + locked flags |
| GET | /api/problems/daily, /api/problems/:id | statement, public tests, starter code (never hidden tests) |
| POST | /api/problems/:id/run | run public tests |
| POST | /api/problems/:id/submit | run all tests, award points once, plagiarism check |
| GET/POST | /api/teams, POST /api/teams/:id/join, /api/teams/leave | squads of 3-4 |
| GET | /api/leaderboard | ranked teams (poll every 5 s) |

## Security
- Passwords: scrypt with a random 16-byte salt per user; constant-time comparison; 8-64 chars, letter + number.
- Sessions: random 256-bit token in an `HttpOnly; SameSite=Strict` cookie; only its SHA-256 is stored; 30-minute idle expiry.
- 5 wrong passwords lock the account for 60 s; same error for unknown users and demo users; per-IP rate limits (429).
- All SQL is parameterised; JSON bodies only, 100 KB limit; Origin check blocks cross-site requests.
- Headers: Content-Security-Policy, X-Content-Type-Options, X-Frame-Options, Referrer-Policy. Static path-traversal guard.
- Judge: worker thread, `vm` context with no `require`/`process`/`fetch`, 1 s CPU limit + 3 s hard kill + 64 MB memory,
  only strings cross the sandbox boundary, runner copies of JSON/Reflect protect against result forging.
  *For a real public deployment, run the worker inside a container.*
- Anti-cheat: hidden tests never leave the server; time and points are computed on the server.

## Extra features
Levenshtein plagiarism check (>= 90 % similar accepted code is flagged), streak calendar API, IST-aware dates, squad size rules.

## Current status / next step
`frontend/` is the previous static build and still runs with its own localStorage. The API is complete and tested;
the next step is switching the frontend's `app.js` from localStorage to `fetch('/api/...')`.
